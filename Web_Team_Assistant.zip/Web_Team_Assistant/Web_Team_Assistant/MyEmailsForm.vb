﻿Imports System.Windows.Forms

Public Class MyEmailsForm
    Public MyMails() As Outlook.MailItem
    Public intRow As Integer

    Private Sub MyEmailsForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Dim olApp As New Outlook.Application
        Dim objNS As Outlook.NameSpace
        Dim olRootFldr As Outlook.MAPIFolder
        Dim olStore As Outlook.Store
        Dim olMail As Outlook.MailItem
        Dim MyBoat As String = ""
        Dim cntMails As Integer = 0

        MyBoat = GetSetting("UCS Assign Mails", "UserDetails", "BoatID", "")

        If MyBoat = "" Then

            MessageBox.Show("BoatID cannot be found!", "Cannot retrieve BoaT ID", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Me.Close()
            Exit Sub
        End If

        objNS = olApp.GetNamespace("MAPI")
        olStore = objNS.Stores("BTC ADVANCED SERVICES G")

        ' default local Inbox
        olRootFldr = olStore.GetRootFolder.Folders("inbox")

        ' Do the needful
        Try
            For Each olMail In olRootFldr.Items


                If InStr(UCase(olMail.Subject), MyBoat) > 0 Then

                    cntMails += 1
                    ReDim Preserve MyMails(cntMails)
                    MyMails(cntMails - 1) = olApp.CreateItem(Outlook.OlItemType.olMailItem)
                    MyMails(cntMails - 1) = olMail
                    dgwMyMails.Rows.Add(New String() {olMail.Subject, olMail.SenderName, _
                                    Format(olMail.ReceivedTime, "MMM-dd HH:mm"), Format(olMail.LastModificationTime, "MMM-dd HH:mm")})
                End If
            Next
            If cntMails = 0 Then
                MessageBox.Show("At the moment there is no email under your name.", "No email was found", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Me.Dispose()
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "An error has been occurred.", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub



    Private Sub dgwMyMails_CellMouseDoubleClick(sender As Object, e As Windows.Forms.DataGridViewCellMouseEventArgs) Handles dgwMyMails.CellMouseDoubleClick

        intRow = dgwMyMails.SelectedCells(0).RowIndex
        Try
            Me.DialogResult = Windows.Forms.DialogResult.OK
        Catch ex As Exception
            MessageBox.Show(ex.Message, "An error has been occurred.", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub

    Private Sub btnOpen_Click(sender As Object, e As EventArgs) Handles btnOpen.Click
        intRow = dgwMyMails.SelectedCells(0).RowIndex
        Try
            Me.DialogResult = Windows.Forms.DialogResult.OK
        Catch ex As Exception
            MessageBox.Show(ex.Message, "An error has been occurred.", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

End Class