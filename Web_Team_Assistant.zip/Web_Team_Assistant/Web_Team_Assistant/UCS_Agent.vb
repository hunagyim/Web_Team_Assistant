﻿Public Class UCS_Agent

    Public FullName As String
    Public BoatID As String
    Public Email As String
    Public FirstName As String
    Public LastName As String
    Public Hash1 As String
    Public Hash2 As String
    Public Hash3 As String
    Public Hash4 As String
    Public Role As String

End Class
