﻿Partial Class Ribbon1
    Inherits Microsoft.Office.Tools.Ribbon.RibbonBase

    <System.Diagnostics.DebuggerNonUserCode()> _
    Public Sub New(ByVal container As System.ComponentModel.IContainer)
        MyClass.New()

        'Required for Windows.Forms Class Composition Designer support
        If (container IsNot Nothing) Then
            container.Add(Me)
        End If

    End Sub

    <System.Diagnostics.DebuggerNonUserCode()> _
    Public Sub New()
        MyBase.New(Globals.Factory.GetRibbonFactory())

        'This call is required by the Component Designer.
        InitializeComponent()

    End Sub

    'Component overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Component Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Component Designer
    'It can be modified using the Component Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim RibbonDialogLauncherImpl1 As Microsoft.Office.Tools.Ribbon.RibbonDialogLauncher = Me.Factory.CreateRibbonDialogLauncher
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Ribbon1))
        Me.tabWebTeamAssist = Me.Factory.CreateRibbonTab
        Me.AgentTools = Me.Factory.CreateRibbonGroup
        Me.ButtonGroup1 = Me.Factory.CreateRibbonButtonGroup
        Me.btnAssignToMe = Me.Factory.CreateRibbonSplitButton
        Me.btnREQ = Me.Factory.CreateRibbonButton
        Me.btnINC = Me.Factory.CreateRibbonButton
        Me.btnNFA = Me.Factory.CreateRibbonButton
        Me.btnRT = Me.Factory.CreateRibbonButton
        Me.btnMyMails = Me.Factory.CreateRibbonButton
        Me.Button1 = Me.Factory.CreateRibbonButton
        Me.ButtonGroup2 = Me.Factory.CreateRibbonButtonGroup
        Me.btnClear = Me.Factory.CreateRibbonButton
        Me.SpltReply = Me.Factory.CreateRibbonSplitButton
        Me.btnReply = Me.Factory.CreateRibbonButton
        Me.btnReplyAll = Me.Factory.CreateRibbonButton
        Me.btnForward = Me.Factory.CreateRibbonButton
        Me.drpTeamCoord = Me.Factory.CreateRibbonDropDown
        Me.btnLaunchEditor = Me.Factory.CreateRibbonButton
        Me.tabWebTeamAssist.SuspendLayout()
        Me.AgentTools.SuspendLayout()
        Me.ButtonGroup1.SuspendLayout()
        Me.ButtonGroup2.SuspendLayout()
        '
        'tabWebTeamAssist
        '
        Me.tabWebTeamAssist.ControlId.ControlIdType = Microsoft.Office.Tools.Ribbon.RibbonControlIdType.Office
        Me.tabWebTeamAssist.ControlId.OfficeId = "TabMail"
        Me.tabWebTeamAssist.Groups.Add(Me.AgentTools)
        Me.tabWebTeamAssist.Label = "TabMail"
        Me.tabWebTeamAssist.Name = "tabWebTeamAssist"
        '
        'AgentTools
        '
        Me.AgentTools.DialogLauncher = RibbonDialogLauncherImpl1
        Me.AgentTools.Items.Add(Me.ButtonGroup1)
        Me.AgentTools.Items.Add(Me.ButtonGroup2)
        Me.AgentTools.Items.Add(Me.drpTeamCoord)
        Me.AgentTools.Label = "Web Team Assistant"
        Me.AgentTools.Name = "AgentTools"
        Me.AgentTools.Position = Me.Factory.RibbonPosition.BeforeOfficeId("GroupMailDelete")
        '
        'ButtonGroup1
        '
        Me.ButtonGroup1.Items.Add(Me.btnAssignToMe)
        Me.ButtonGroup1.Items.Add(Me.Button1)
        Me.ButtonGroup1.Name = "ButtonGroup1"
        '
        'btnAssignToMe
        '
        Me.btnAssignToMe.Image = CType(resources.GetObject("btnAssignToMe.Image"), System.Drawing.Image)
        Me.btnAssignToMe.Items.Add(Me.btnREQ)
        Me.btnAssignToMe.Items.Add(Me.btnINC)
        Me.btnAssignToMe.Items.Add(Me.btnNFA)
        Me.btnAssignToMe.Items.Add(Me.btnRT)
        Me.btnAssignToMe.Items.Add(Me.btnMyMails)
        Me.btnAssignToMe.ItemSize = Microsoft.Office.Core.RibbonControlSize.RibbonControlSizeLarge
        Me.btnAssignToMe.Label = "Assign Task to Me"
        Me.btnAssignToMe.Name = "btnAssignToMe"
        '
        'btnREQ
        '
        Me.btnREQ.ControlSize = Microsoft.Office.Core.RibbonControlSize.RibbonControlSizeLarge
        Me.btnREQ.Image = CType(resources.GetObject("btnREQ.Image"), System.Drawing.Image)
        Me.btnREQ.Label = "As Request"
        Me.btnREQ.Name = "btnREQ"
        Me.btnREQ.ShowImage = True
        '
        'btnINC
        '
        Me.btnINC.ControlSize = Microsoft.Office.Core.RibbonControlSize.RibbonControlSizeLarge
        Me.btnINC.Image = CType(resources.GetObject("btnINC.Image"), System.Drawing.Image)
        Me.btnINC.Label = "As Incident"
        Me.btnINC.Name = "btnINC"
        Me.btnINC.ShowImage = True
        '
        'btnNFA
        '
        Me.btnNFA.ControlSize = Microsoft.Office.Core.RibbonControlSize.RibbonControlSizeLarge
        Me.btnNFA.Image = CType(resources.GetObject("btnNFA.Image"), System.Drawing.Image)
        Me.btnNFA.Label = "As NFA"
        Me.btnNFA.Name = "btnNFA"
        Me.btnNFA.ShowImage = True
        '
        'btnRT
        '
        Me.btnRT.ControlSize = Microsoft.Office.Core.RibbonControlSize.RibbonControlSizeLarge
        Me.btnRT.Image = Global.Web_Team_Assistant.My.Resources.Resources.RT2
        Me.btnRT.Label = "Open RT"
        Me.btnRT.Name = "btnRT"
        Me.btnRT.ShowImage = True
        '
        'btnMyMails
        '
        Me.btnMyMails.ControlSize = Microsoft.Office.Core.RibbonControlSize.RibbonControlSizeLarge
        Me.btnMyMails.Image = CType(resources.GetObject("btnMyMails.Image"), System.Drawing.Image)
        Me.btnMyMails.Label = "My Emails"
        Me.btnMyMails.Name = "btnMyMails"
        Me.btnMyMails.ShowImage = True
        '
        'Button1
        '
        Me.Button1.Label = " "
        Me.Button1.Name = "Button1"
        '
        'ButtonGroup2
        '
        Me.ButtonGroup2.Items.Add(Me.btnClear)
        Me.ButtonGroup2.Items.Add(Me.SpltReply)
        Me.ButtonGroup2.Name = "ButtonGroup2"
        '
        'btnClear
        '
        Me.btnClear.Image = CType(resources.GetObject("btnClear.Image"), System.Drawing.Image)
        Me.btnClear.Label = "Clear"
        Me.btnClear.Name = "btnClear"
        Me.btnClear.ShowImage = True
        '
        'SpltReply
        '
        Me.SpltReply.Image = CType(resources.GetObject("SpltReply.Image"), System.Drawing.Image)
        Me.SpltReply.Items.Add(Me.btnReply)
        Me.SpltReply.Items.Add(Me.btnReplyAll)
        Me.SpltReply.Items.Add(Me.btnForward)
        Me.SpltReply.ItemSize = Microsoft.Office.Core.RibbonControlSize.RibbonControlSizeLarge
        Me.SpltReply.Label = "Reply"
        Me.SpltReply.Name = "SpltReply"
        Me.SpltReply.ScreenTip = "Reply to the Task"
        '
        'btnReply
        '
        Me.btnReply.ControlSize = Microsoft.Office.Core.RibbonControlSize.RibbonControlSizeLarge
        Me.btnReply.Image = CType(resources.GetObject("btnReply.Image"), System.Drawing.Image)
        Me.btnReply.Label = "To Email"
        Me.btnReply.Name = "btnReply"
        Me.btnReply.ShowImage = True
        '
        'btnReplyAll
        '
        Me.btnReplyAll.ControlSize = Microsoft.Office.Core.RibbonControlSize.RibbonControlSizeLarge
        Me.btnReplyAll.Image = CType(resources.GetObject("btnReplyAll.Image"), System.Drawing.Image)
        Me.btnReplyAll.Label = "To All"
        Me.btnReplyAll.Name = "btnReplyAll"
        Me.btnReplyAll.ShowImage = True
        '
        'btnForward
        '
        Me.btnForward.ControlSize = Microsoft.Office.Core.RibbonControlSize.RibbonControlSizeLarge
        Me.btnForward.Image = Global.Web_Team_Assistant.My.Resources.Resources.buzz_forward_icon
        Me.btnForward.Label = "Forward Email"
        Me.btnForward.Name = "btnForward"
        Me.btnForward.ShowImage = True
        '
        'drpTeamCoord
        '
        Me.drpTeamCoord.Image = Global.Web_Team_Assistant.My.Resources.Resources.teamcordassignto
        Me.drpTeamCoord.Label = "Assign Task To"
        Me.drpTeamCoord.Name = "drpTeamCoord"
        Me.drpTeamCoord.ShowImage = True
        Me.drpTeamCoord.Visible = False
        '
        'btnLaunchEditor
        '
        Me.btnLaunchEditor.Label = "Launch Template Editor"
        Me.btnLaunchEditor.Name = "btnLaunchEditor"
        Me.btnLaunchEditor.ShowImage = True
        '
        'Ribbon1
        '
        Me.Name = "Ribbon1"
        '
        'Ribbon1.OfficeMenu
        '
        Me.OfficeMenu.Items.Add(Me.btnLaunchEditor)
        Me.RibbonType = "Microsoft.Outlook.Explorer, Microsoft.Outlook.Mail.Compose, Microsoft.Outlook.Mai" & _
    "l.Read"
        Me.Tabs.Add(Me.tabWebTeamAssist)
        Me.tabWebTeamAssist.ResumeLayout(False)
        Me.tabWebTeamAssist.PerformLayout()
        Me.AgentTools.ResumeLayout(False)
        Me.AgentTools.PerformLayout()
        Me.ButtonGroup1.ResumeLayout(False)
        Me.ButtonGroup1.PerformLayout()
        Me.ButtonGroup2.ResumeLayout(False)
        Me.ButtonGroup2.PerformLayout()

    End Sub

    Friend WithEvents tabWebTeamAssist As Microsoft.Office.Tools.Ribbon.RibbonTab
    Friend WithEvents AgentTools As Microsoft.Office.Tools.Ribbon.RibbonGroup
    Friend WithEvents ButtonGroup1 As Microsoft.Office.Tools.Ribbon.RibbonButtonGroup
    Friend WithEvents btnAssignToMe As Microsoft.Office.Tools.Ribbon.RibbonSplitButton
    Friend WithEvents btnREQ As Microsoft.Office.Tools.Ribbon.RibbonButton
    Friend WithEvents btnINC As Microsoft.Office.Tools.Ribbon.RibbonButton
    Friend WithEvents btnNFA As Microsoft.Office.Tools.Ribbon.RibbonButton
    Friend WithEvents ButtonGroup2 As Microsoft.Office.Tools.Ribbon.RibbonButtonGroup
    Friend WithEvents btnClear As Microsoft.Office.Tools.Ribbon.RibbonButton
    Friend WithEvents SpltReply As Microsoft.Office.Tools.Ribbon.RibbonSplitButton
    Friend WithEvents btnReply As Microsoft.Office.Tools.Ribbon.RibbonButton
    Friend WithEvents btnReplyAll As Microsoft.Office.Tools.Ribbon.RibbonButton
    Friend WithEvents btnMyMails As Microsoft.Office.Tools.Ribbon.RibbonButton
    Public WithEvents drpTeamCoord As Microsoft.Office.Tools.Ribbon.RibbonDropDown
    Friend WithEvents Button1 As Microsoft.Office.Tools.Ribbon.RibbonButton
    Friend WithEvents btnRT As Microsoft.Office.Tools.Ribbon.RibbonButton
    Friend WithEvents btnForward As Microsoft.Office.Tools.Ribbon.RibbonButton
    Friend WithEvents btnLaunchEditor As Microsoft.Office.Tools.Ribbon.RibbonButton
End Class

Partial Class ThisRibbonCollection

    <System.Diagnostics.DebuggerNonUserCode()> _
    Friend ReadOnly Property Ribbon1() As Ribbon1
        Get
            Return Me.GetRibbon(Of Ribbon1)()
        End Get
    End Property
End Class
