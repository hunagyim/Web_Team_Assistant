﻿Imports System.Data.OleDb
Imports System.Data
Imports System.Runtime.InteropServices

Public Class DBControl

    ' Database connection & connection string determined by the Constructor
    Private ConnectionString As String

    ' Database command variable
    Private DBCmd As OleDbCommand

    ' Database DATA handler variables (adapter and datatable)
    Public DBDA As OleDbDataAdapter
    Public DBDT As DataTable

    ' Parameter List for queries
    Public Params As New List(Of OleDbParameter)

    ' Query Statistics
    Public RecordCount As Integer
    Public Exception As String ' error message of the exception


    ' Constructor
    Sub New(ByVal s As String)
        ConnectionString = s
    End Sub

    ' Sub to run queries
    Public Sub ExecQuery(Query As String)

        ' Reset query statistics
        RecordCount = 0
        Exception = ""
        Dim DBCon As New OleDbConnection(ConnectionString)

        Try

            ' Open a connection
            DBCon.Open()

            ' Create the command from the query 
            DBCmd = New OleDbCommand(Query, DBCon)

            ' Load parameters into the command
            Params.ForEach(Sub(p) DBCmd.Parameters.Add(p))

            ' Clear Parameter list (for the next command)
            Params.Clear()

            ' Execute the commmand and populate the DataTable
            DBDT = New DataTable
            DBDA = New OleDbDataAdapter(DBCmd)
            RecordCount = DBDA.Fill(DBDT)

        Catch ex As Exception
            Exception = ex.Message
        End Try

        ' Close the connection, if it is still open
        If DBCon.State = ConnectionState.Open Then DBCon.Close()

    End Sub

    ' Include query and command parameters
    Public Sub AddParam(name As String, Value As Object)

        Dim NewParam As New OleDbParameter(name, Value)
        Params.Add(NewParam)

    End Sub

End Class
