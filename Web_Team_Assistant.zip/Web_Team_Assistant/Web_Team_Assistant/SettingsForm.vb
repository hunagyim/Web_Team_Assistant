﻿Imports System.Drawing
Imports System.Data
Imports System.IO
Imports System.Windows.Forms



Public Class SettingsForm

    Private strEmail As String
    Private strFirstName As String
    Private strLastName As String
    Private strBoatID As String
    Private strRole As String
    Private strHash1, strHash2 As String
    Private strHash3, strHash4 As String
    Private strTemplateName As String = ""
    Private strPwTemplateName As String = ""

    Private isChange As Boolean = False
    Private isTempChange As Boolean = False
    Private isPwTempChange As Boolean = False

    Public Change2TC As Boolean = False

    Private Sub btnOK_Click(sender As Object, e As EventArgs) Handles btnOK.Click

        If strEmail <> txtEmail.Text Then SaveSetting("UCS Assign Mails", "UserDetails", "Email", txtEmail.Text)
        If strFirstName <> txtFirstName.Text Then SaveSetting("UCS Assign Mails", "UserDetails", "FirstName", txtFirstName.Text)
        If strLastName <> txtLastName.Text Then SaveSetting("UCS Assign Mails", "UserDetails", "LastName", txtLastName.Text)
        If strBoatID <> txtBoat.Text Then SaveSetting("UCS Assign Mails", "UserDetails", "BoatID", txtBoat.Text)
        If strHash1 <> txtHash1.Text Then SaveSetting("UCS Assign Mails", "UserDetails", "Hash1", txtHash1.Text)
        If strHash2 <> txtHash2.Text Then SaveSetting("UCS Assign Mails", "UserDetails", "Hash2", txtHash2.Text)
        If strHash3 <> txtHash3.Text Then SaveSetting("UCS Assign Mails", "UserDetails", "Hash3", txtHash3.Text)
        If strHash4 <> txtHash4.Text Then SaveSetting("UCS Assign Mails", "UserDetails", "Hash4", txtHash4.Text)

        ' This one is a special case, if the role's changed to 2, we need to enable the TC dropdown
        If strEmail <> txtRole.Text Then
            SaveSetting("UCS Assign Mails", "UserDetails", "Role", txtRole.Text)
            Change2TC = True
        End If

        If strTemplateName <> cbxTemplate.SelectedItem.ToString Then
            SaveSetting("UCS Assign Mails", "UserDetails", "DefaultTemplate", cbxTemplate.SelectedItem.ToString)
        End If
        If strPwTemplateName <> cbxPwTemplate.SelectedItem.ToString Then
            SaveSetting("UCS Assign Mails", "UserDetails", "DefaultPasswordTemplate", cbxPwTemplate.SelectedItem.ToString)
        End If

        Me.DialogResult = Windows.Forms.DialogResult.OK

    End Sub

    Private Sub SettingsForm_Load(sender As Object, e As EventArgs) Handles Me.Load

        Dim fileEntries As String() '= Directory.GetFiles(CStr(Environ("USERPROFILE")) & "\Documents\MyTemplates")
        Dim fileName As String

        ' Populate the text field from the registry
        strEmail = GetSetting("UCS Assign Mails", "UserDetails", "Email", "")
        strFirstName = GetSetting("UCS Assign Mails", "UserDetails", "FirstName", "")
        strLastName = GetSetting("UCS Assign Mails", "UserDetails", "LastName", "")
        strBoatID = GetSetting("UCS Assign Mails", "UserDetails", "BoatID", "")
        strRole = GetSetting("UCS Assign Mails", "UserDetails", "Role", "")
        strHash1 = GetSetting("UCS Assign Mails", "UserDetails", "Hash1", "")
        strHash2 = GetSetting("UCS Assign Mails", "UserDetails", "Hash2", "")
        strHash3 = GetSetting("UCS Assign Mails", "UserDetails", "Hash3", "")
        strHash4 = GetSetting("UCS Assign Mails", "UserDetails", "Hash4", "")


        txtEIN.Text = CStr(Environ("USERNAME"))
        txtEmail.Text = strEmail
        txtFirstName.Text = strFirstName
        txtLastName.Text = strLastName
        txtBoat.Text = strBoatID
        txtRole.Text = strRole
        txtHash1.Text = strHash1
        txtHash2.Text = strHash2
        txtHash3.Text = strHash3
        txtHash4.Text = strHash4

        If strEmail = "" Then txtEmail.Enabled = True : btnOK.Enabled = True
        If strFirstName = "" Then txtFirstName.Enabled = True : btnOK.Enabled = True
        If strLastName = "" Then txtLastName.Enabled = True : btnOK.Enabled = True
        If strBoatID = "" Then txtBoat.Enabled = True : btnOK.Enabled = True
        If strHash1 = "" Then txtHash1.Enabled = True : btnOK.Enabled = True
        If strHash2 = "" Then txtHash2.Enabled = True : btnOK.Enabled = True
        If strHash3 = "" Then txtHash3.Enabled = True : btnOK.Enabled = True
        If strHash4 = "" Then txtHash4.Enabled = True : btnOK.Enabled = True

        ' Filling the combobox with templates

        If Directory.Exists(CStr(Environ("USERPROFILE")) & "\Documents\MyTemplates") Then
            fileEntries = Directory.GetFiles(CStr(Environ("USERPROFILE")) & "\Documents\MyTemplates")
        Else
            Exit Sub
        End If


        cbxTemplate.Items.Add("(none)")
        cbxPwTemplate.Items.Add("(none)")
        For Each fileName In fileEntries
            If Microsoft.VisualBasic.Right(fileName, 4) = ".htm" And InStr(fileName, "MySignature") = 0 Then
                cbxTemplate.Items.Add(Path.GetFileNameWithoutExtension(fileName))
                cbxPwTemplate.Items.Add(Path.GetFileNameWithoutExtension(fileName))
            End If
        Next

        strTemplateName = GetSetting("UCS Assign Mails", "UserDetails", "DefaultTemplate", "")
        strPwTemplateName = GetSetting("UCS Assign Mails", "UserDetails", "DefaultPasswordTemplate", "")

        If String.IsNullOrEmpty(strTemplateName) Then
            cbxTemplate.SelectedIndex = 0
            SaveSetting("UCS Assign Mails", "UserDetails", "DefaultTemplate", "(none)")
            strTemplateName = "(none)"
        Else
            cbxTemplate.SelectedIndex = cbxTemplate.FindString(strTemplateName)
            If cbxTemplate.SelectedItem.ToString <> strTemplateName Then
                Do Until cbxTemplate.SelectedItem.ToString = strTemplateName
                    cbxTemplate.SelectedIndex = cbxTemplate.FindString(strTemplateName, cbxTemplate.SelectedIndex)
                Loop
            End If
        End If

        If String.IsNullOrEmpty(strPwTemplateName) Then
            cbxPwTemplate.SelectedIndex = 0
            SaveSetting("UCS Assign Mails", "UserDetails", "DefaultPasswordTemplate", "(none)")
            strTemplateName = "(none)"
        Else
            cbxPwTemplate.SelectedIndex = cbxPwTemplate.FindString(strPwTemplateName)
            If cbxPwTemplate.SelectedItem.ToString <> strPwTemplateName Then
                Do Until cbxPwTemplate.SelectedItem.ToString = strPwTemplateName
                    cbxPwTemplate.SelectedIndex = cbxPwTemplate.FindString(strPwTemplateName, cbxPwTemplate.SelectedIndex)
                Loop
            End If
        End If

    End Sub



    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click

        Dim Access As New DBControl(ConnString)
        Dim cntDiff As Integer = 0

        Access.AddParam("@user", txtEIN.Text)
        Access.ExecQuery("SELECT * FROM AgentDetails WHERE EINnumber = @user")
        If Not String.IsNullOrEmpty(Access.Exception) Then
            MessageBox.Show("Cannot access database. Update failed" & vbCrLf & Access.Exception, "Connection error", _
                            MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End If

        If Access.RecordCount = 0 Then
            MessageBox.Show("Cannot find EIN number in database" & vbCrLf & Access.Exception, "Connection error", _
                            MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End If

        Dim R As DataRow = Access.DBDT.Rows(0)
        If txtBoat.Text <> R("BoatID") Then
            txtBoat.Text = R("BoatID")
            txtBoat.BackColor = Color.LightBlue
            cntDiff += 1
        Else
            txtBoat.BackColor = Color.LightGreen
        End If

        If txtEmail.Text <> R("Email") Then
            txtEmail.Text = R("Email")
            txtEmail.BackColor = Color.LightBlue
            cntDiff += 1
        Else
            txtEmail.BackColor = Color.LightGreen
        End If

        If txtFirstName.Text <> R("FirstName") Then
            txtFirstName.Text = R("FirstName")
            txtFirstName.BackColor = Color.LightBlue
            cntDiff += 1
        Else
            txtFirstName.BackColor = Color.LightGreen
        End If

        If txtLastName.Text <> R("LastName") Then
            txtLastName.Text = R("LastName")
            txtLastName.BackColor = Color.LightBlue
            cntDiff += 1
        Else
            txtLastName.BackColor = Color.LightGreen
        End If

        If txtRole.Text <> R("Role") Then
            txtRole.Text = R("Role")
            txtRole.BackColor = Color.LightBlue
            cntDiff += 1
        Else
            txtRole.BackColor = Color.LightGreen
        End If

        If txtHash1.Text <> R("Hash1") Then
            txtHash1.Text = R("Hash1")
            txtHash1.BackColor = Color.LightBlue
            cntDiff += 1
        Else
            txtHash1.BackColor = Color.LightGreen
        End If
        If txtHash2.Text <> R("Hash2") Then
            txtHash2.Text = R("Hash2")
            txtHash2.BackColor = Color.LightBlue
            cntDiff += 1
        Else
            txtHash2.BackColor = Color.LightGreen
        End If
        If txtHash3.Text <> R("Hash3") Then
            txtHash3.Text = R("Hash3")
            txtHash3.BackColor = Color.LightBlue
            cntDiff += 1
        Else
            txtHash3.BackColor = Color.LightGreen
        End If
        If txtHash4.Text <> R("Hash4") Then
            txtHash4.Text = R("Hash4")
            txtHash4.BackColor = Color.LightBlue
            cntDiff += 1
        Else
            txtHash4.BackColor = Color.LightGreen
        End If


        btnUpdate.Enabled = False
        If cntDiff > 0 Then
            btnOK.Enabled = True
            btnCancel.Text = "Cancel"
            isChange = True
        End If

    End Sub

    Private Sub cbxTemplate_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbxTemplate.SelectedIndexChanged
        If cbxTemplate.SelectedItem.ToString <> strTemplateName Then
            btnOK.Enabled = True
            isTempChange = True
        Else
            If isChange = False And isPwTempChange = False Then btnOK.Enabled = False
            isTempChange = False
        End If
    End Sub

    Private Sub cbxPwTemplate_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbxPwTemplate.SelectedIndexChanged
        If cbxPwTemplate.SelectedItem.ToString <> strPwTemplateName Then
            btnOK.Enabled = True
            isPwTempChange = True
        Else
            If isChange = False And isTempChange = False Then btnOK.Enabled = False
            isPwTempChange = False
        End If
    End Sub

    Private Sub DeleteMacroFromRegistry()

        DeleteSetting("UCS Assign Mails")

    End Sub


End Class