﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ReplyMailForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblCompleteMail = New System.Windows.Forms.Label()
        Me.rbtnREQ = New System.Windows.Forms.RadioButton()
        Me.rbtnINC = New System.Windows.Forms.RadioButton()
        Me.btnOK = New System.Windows.Forms.Button()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lblCompleteMail
        '
        Me.lblCompleteMail.AutoSize = True
        Me.lblCompleteMail.Location = New System.Drawing.Point(9, 9)
        Me.lblCompleteMail.Name = "lblCompleteMail"
        Me.lblCompleteMail.Size = New System.Drawing.Size(156, 39)
        Me.lblCompleteMail.TabIndex = 0
        Me.lblCompleteMail.Text = "Before moving the mail to the " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "'Email Done' folder, please " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "select a category, " & _
    "or hit Cancel:"
        '
        'rbtnREQ
        '
        Me.rbtnREQ.AutoSize = True
        Me.rbtnREQ.Location = New System.Drawing.Point(12, 62)
        Me.rbtnREQ.Name = "rbtnREQ"
        Me.rbtnREQ.Size = New System.Drawing.Size(65, 17)
        Me.rbtnREQ.TabIndex = 1
        Me.rbtnREQ.TabStop = True
        Me.rbtnREQ.Text = "Request"
        Me.rbtnREQ.UseVisualStyleBackColor = True
        '
        'rbtnINC
        '
        Me.rbtnINC.AutoSize = True
        Me.rbtnINC.Location = New System.Drawing.Point(12, 104)
        Me.rbtnINC.Name = "rbtnINC"
        Me.rbtnINC.Size = New System.Drawing.Size(63, 17)
        Me.rbtnINC.TabIndex = 2
        Me.rbtnINC.TabStop = True
        Me.rbtnINC.Text = "Incident"
        Me.rbtnINC.UseVisualStyleBackColor = True
        '
        'btnOK
        '
        Me.btnOK.Location = New System.Drawing.Point(108, 62)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(75, 23)
        Me.btnOK.TabIndex = 4
        Me.btnOK.Text = "OK"
        Me.btnOK.UseVisualStyleBackColor = True
        '
        'btnCancel
        '
        Me.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnCancel.Location = New System.Drawing.Point(108, 104)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(75, 23)
        Me.btnCancel.TabIndex = 5
        Me.btnCancel.Text = "Cancel"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'ReplyMailForm
        '
        Me.AcceptButton = Me.btnOK
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.btnCancel
        Me.ClientSize = New System.Drawing.Size(200, 137)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnOK)
        Me.Controls.Add(Me.rbtnINC)
        Me.Controls.Add(Me.rbtnREQ)
        Me.Controls.Add(Me.lblCompleteMail)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "ReplyMailForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Complete Mail"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblCompleteMail As System.Windows.Forms.Label
    Friend WithEvents rbtnREQ As System.Windows.Forms.RadioButton
    Friend WithEvents rbtnINC As System.Windows.Forms.RadioButton
    Friend WithEvents btnOK As System.Windows.Forms.Button
    Friend WithEvents btnCancel As System.Windows.Forms.Button
End Class
