﻿Imports System.Windows.Forms
Imports System.Runtime.InteropServices

Module Module_AgentStatus

    Private mailsubject As String = ""

    Public Enum MailStatus
        Taken = 1
        TakenREQ = 2
        TakenINC = 3
        TakenNFA = 4
        NotMine = 5
        NotTaken = 0
        NA = -1
    End Enum
    Public Function GetStatus(olMail As Object) As MailStatus

        Dim tmpStatus As MailStatus
        Dim BoatID As String
        Dim strowner As String


        BoatID = "***" & GetSetting("UCS Assign Mails", "UserDetails", "BoatID", "") & "***"
        If BoatID = "******" Then BoatID = "***" & ReAuthXL() & "***"
        If BoatID = "***NA***" Then
            MessageBox.Show("Cannot retrieve your BoaT ID. Please contact the creators. Also bring Aladdin Gyros. We love it.", _
                            "Registration error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return MailStatus.NA
            Exit Function
        End If

        If GetOwner(olMail) = 0 Then
            Return MailStatus.NotTaken
        End If

        strowner = UCase(arrBoatIDs(GetOwner(olMail) - 1))
        If InStr(UCase(BoatID), strowner) = 0 Then
            Return MailStatus.NotMine
        End If

        If InStr(UCase(olMail.Subject), BoatID) > 0 Then
            If InStr(UCase(olMail.Subject), BoatID & "REQ***") > 0 Then
                tmpStatus = MailStatus.TakenREQ
            ElseIf InStr(UCase(olMail.Subject), BoatID & "INC***") > 0 Then
                tmpStatus = MailStatus.TakenINC
            ElseIf InStr(UCase(olMail.Subject), BoatID & "NFA***") > 0 Then
                tmpStatus = MailStatus.TakenNFA
            Else
                tmpStatus = MailStatus.Taken
            End If
        End If

        Return tmpStatus

    End Function

    Public Sub SetStatus(olMail As Object, st As MailStatus)


        Dim strSt As String
        Dim BoatID As String
        Dim intOwner As Integer
        Dim strOwner As String

        If GetStatus(olMail) = st Then Exit Sub

        BoatID = "***" & GetSetting("UCS Assign Mails", "UserDetails", "BoatID", "") & "***"
        If BoatID = "******" Then BoatID = "***" & ReAuthXL() & "***"
        If BoatID = "***NA***" Then
            MessageBox.Show("Cannot retrieve your BoaT ID. Please contact the creators. Also bring Aladdin Gyros. We love it.", _
                                        "Registration error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End If
        strSt = ""


        Select Case st
            Case MailStatus.Taken
                strSt = BoatID
            Case MailStatus.TakenREQ
                strSt = BoatID & "REQ***"
            Case MailStatus.TakenINC
                strSt = BoatID & "INC***"
            Case MailStatus.TakenNFA
                strSt = BoatID & "NFA***"
        End Select

        intOwner = GetOwner(olMail)
        If intOwner <> 0 Then

            strOwner = arrBoatIDs(intOwner - 1)
            If InStr(olMail.Subject, "***" & strOwner & "***REQ***") > 0 Then
                olMail.Subject = Replace(olMail.Subject, "***" & strOwner & "***REQ***", "")
            ElseIf InStr(olMail.Subject, "***" & strOwner & "***INC***") > 0 Then
                olMail.Subject = Replace(olMail.Subject, "***" & strOwner & "***INC***", "")
            ElseIf InStr(olMail.Subject, "***" & strOwner & "***NFA***") > 0 Then
                olMail.Subject = Replace(olMail.Subject, "***" & strOwner & "***NFA***", "")
            Else
                olMail.Subject = Replace(olMail.Subject, "***" & strOwner & "***", "")
            End If
            'olMail.Save()
        End If
        olMail.Subject = strSt & olMail.Subject
        olMail.Save()

    End Sub

    Public Function GetOwner(olMail As Object) As Integer

        For i = 0 To UBound(arrBoatIDs) - 1
            If InStr(olMail.Subject, "***" & arrBoatIDs(i) & "***") Then
                Return i + 1
            End If
        Next
        Return 0

    End Function

End Module
