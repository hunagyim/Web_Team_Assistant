﻿Imports Microsoft.Office.Tools.Ribbon
Imports Outlook = Microsoft.Office.Interop.Outlook
Imports Microsoft.Office.Tools
Imports Excel = Microsoft.Office.Interop.Excel
Imports System.Net.Mail
Imports Shell32
Imports SHDocVw
Imports System.Windows.Forms
Imports System
Imports System.IO
Imports System.Collections
Imports System.Data
Imports System.Runtime.InteropServices
Imports Microsoft.Exchange.WebServices.Data

Public Class Ribbon1

    'Dim objItem As Outlook.MailItem
    Dim strSub As String
    Dim funny As Integer = 0

    'Private Access As New DBControl(ConnString)
    Private Sub btnAssignToMe_Click(sender As Object, e As RibbonControlEventArgs) Handles btnAssignToMe.Click

        Call TakeMail()

    End Sub

    ' Handling the REQ, INC and NFA buttons
    Private Sub btnREQ_Click(sender As Object, e As RibbonControlEventArgs) Handles btnREQ.Click
        Call SetREQ()
    End Sub

    Private Sub btnINC_Click(sender As Object, e As RibbonControlEventArgs) Handles btnINC.Click
        Call SetINC()
    End Sub

    Private Sub btnNFA_Click(sender As Object, e As RibbonControlEventArgs) Handles btnNFA.Click
        Call SetNFA()
    End Sub
    Private Sub btnClear_Click(sender As Object, e As RibbonControlEventArgs) Handles btnClear.Click
        Call ClearStatus()
    End Sub

    Sub TakeMail()

        Dim olApp As New Outlook.Application
        Dim olExplorer As Outlook.Explorer = olApp.ActiveExplorer
        Dim olSelection As Outlook.Selection = olExplorer.Selection
        Dim olMail As Object

        If olSelection.Count > 0 Then
            For Each olMail In olSelection

                Call TakeOneMail(olMail)
                Marshal.ReleaseComObject(olMail)
            Next
            Marshal.ReleaseComObject(olSelection)
        End If
        Marshal.ReleaseComObject(olExplorer)
    End Sub

    Sub TakeOneMail(olItem As Object)

        Select GetStatus(olItem)
            Case MailStatus.NA
                Exit Sub
            Case MailStatus.Taken
                MessageBox.Show("This email is already under your name : " & olItem.Subject, "Email already taken", _
                                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Case MailStatus.NotMine
                If MessageBox.Show("This is email is already taken by " & arrAgents(GetOwner(olItem) - 1) & ". Would you like to steal it?", _
                                   "Email is already taken", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.Yes Then
                    Call SetStatus(olItem, MailStatus.Taken)
                End If
            Case Else
                Call SetStatus(olItem, MailStatus.Taken)
        End Select
    End Sub

    Sub SetREQ()

        Dim objApp As New Outlook.Application
        Dim objItem As Object

        For Each objItem In objApp.ActiveExplorer.Selection

            If GetStatus(objItem) = MailStatus.NA Then Exit For
            If GetStatus(objItem) <> MailStatus.TakenREQ Then Call SetStatus(objItem, MailStatus.TakenREQ)

        Next

    End Sub

    Sub SetINC()

        Dim objApp As New Outlook.Application
        Dim objItem As Object

        For Each objItem In objApp.ActiveExplorer.Selection

            If GetStatus(objItem) = MailStatus.NA Then Exit For
            If GetStatus(objItem) <> MailStatus.TakenINC Then Call SetStatus(objItem, MailStatus.TakenINC)

        Next

    End Sub

    Sub SetNFA()

        Dim objApp As New Outlook.Application
        Dim objItem As Object

        For Each objItem In objApp.ActiveExplorer.Selection

            If GetStatus(objItem) = MailStatus.NA Then Exit For
            If GetStatus(objItem) <> MailStatus.TakenNFA Then Call SetStatus(objItem, MailStatus.TakenNFA)

        Next

    End Sub

    Sub ClearStatus()
        Dim objItem As Object

        Dim objApp As New Outlook.Application
        For Each objItem In objApp.ActiveExplorer.Selection
            Call SetStatus(objItem, MailStatus.NotTaken)
        Next

    End Sub

    Private Sub releaseObject(ByVal obj As Object)
        Try
            Dim intRel As Integer = 0
            Do
                intRel = System.Runtime.InteropServices.Marshal.ReleaseComObject(obj)
            Loop While intRel > 0
        Catch ex As Exception
            obj = Nothing
        Finally
            GC.Collect()
        End Try
    End Sub

    'Handling the MyReply buttons
    Private Sub SpltReply_Click(sender As Object, e As RibbonControlEventArgs) Handles SpltReply.Click
        Call MyReply()      
    End Sub


    Private Sub btnReply_Click(sender As Object, e As RibbonControlEventArgs) Handles btnReply.Click
        Call MyReply()
    End Sub

    Private Sub btnReplyAll_Click(sender As Object, e As RibbonControlEventArgs) Handles btnReplyAll.Click
        Call MyReplyAll()
    End Sub

    Private Sub btnForward_Click(sender As Object, e As RibbonControlEventArgs) Handles btnForward.Click
        Call ForwardMail()
    End Sub

    Private Sub drpTeamCoord_ButtonClick(sender As Object, e As RibbonControlEventArgs) Handles drpTeamCoord.SelectionChanged

        Dim strBoat As String
        Dim olApp As New Outlook.Application

        If drpTeamCoord.SelectedItem.Label = "" Or olApp.ActiveExplorer.Selection.Count = 0 Then Exit Sub
        strBoat = arrBoatIDs(drpTeamCoord.SelectedItemIndex - 1)

        'Easter Egg
        If strBoat = "DELNEKA" Then
            MessageBox.Show("Nice try! Our Master does not waste time with pesky mails.", "Not this time", MessageBoxButtons.OK, MessageBoxIcon.Information)
            drpTeamCoord.SelectedItemIndex = 0
            Exit Sub
        End If

        With olApp.ActiveExplorer.Selection

            If .Count = 1 Then

                Call AssignTo(.Item(1), strBoat, True)

            Else
                If MessageBox.Show("You selected multiple items. Would you like to assign these emails to " & drpTeamCoord.SelectedItem.Label _
                          & "? (Overwrite if email is already assigned)", "Overwrite emails", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = MsgBoxResult.Yes Then
                    For i = 1 To .Count
                        Call AssignTo(.Item(i), strBoat, False)
                    Next i
                End If
            End If

        End With

        drpTeamCoord.SelectedItemIndex = 0

    End Sub

    Private Sub AssignTo(objItem As Object, strAgent As String, isConfirm As Boolean)

        For i = 0 To UBound(arrBoatIDs) - 1
            If InStr(UCase(objItem.Subject), arrBoatIDs(i)) > 0 Then

                If strAgent = arrBoatIDs(i) Then Exit Sub
                If isConfirm Then
                    If MessageBox.Show("The selected email is already assigned to " & drpTeamCoord.Items.Item(i + 1).Label & ". Would you like to reassign it to " & _
                              drpTeamCoord.SelectedItem.Label & "?", "Assign email to another agent", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = MsgBoxResult.No Then
                        Exit Sub
                    End If
                End If

                Dim startPos, endPos As Integer
                Dim newSubject As String = ""
                startPos = InStr(UCase(objItem.subject), arrBoatIDs(i))
                endPos = startPos + Len(arrBoatIDs(i))
                newSubject = Left(objItem.subject, startPos - 1)
                newSubject &= strAgent
                newSubject &= Right(objItem.subject, Len(objItem.subject) - endPos + 1)

                objItem.Subject = newSubject
                objItem.Save()
                Exit Sub
            End If

        Next i
        objItem.Subject = "***" & strAgent & "***" & objItem.Subject
        objItem.Save()


    End Sub

    ' Showing the MyEmails form 
    Private Sub btnMyMails_Click(sender As Object, e As RibbonControlEventArgs) Handles btnMyMails.Click

        Dim frmMyMails As New MyEmailsForm

        If frmMyMails.ShowDialog = DialogResult.OK Then
            Try
                frmMyMails.MyMails(frmMyMails.intRow).Display()
            Catch ex As Exception
                MessageBox.Show(ex.Message, "An error has been occurred.", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End If

    End Sub

    Private Sub ShowSettingsForm() Handles AgentTools.DialogLauncherClick

        Dim frmSettings As New SettingsForm

        If frmSettings.ShowDialog = Windows.Forms.DialogResult.OK Then
            If frmSettings.Change2TC Then
                drpTeamCoord.Visible = True
                Call FillTCDropDown()
            Else
                drpTeamCoord.Visible = False
            End If
            MessageBox.Show("Your details have been updated.", "Update successful", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If

    End Sub

    Private Sub Button1_Click(sender As Object, e As RibbonControlEventArgs) Handles Button1.Click
        Dim frmAbout As New AboutBox
        Dim frmFunny As New Form1

        If funny < 5 Then
            frmAbout.ShowDialog()
            funny = funny + 1
        ElseIf funny = 5 Then
            frmFunny.ShowDialog()
            funny = funny + 1
        Else
            frmAbout.ShowDialog()
            funny = 0
        End If

    End Sub

    Private Sub btnRT_Click(sender As Object, e As RibbonControlEventArgs) Handles btnRT.Click
        System.Diagnostics.Process.Start("https://ticket.btci.com/Search/Results.html?Query=Queue+%3D+%273%27+AND+%28Status+%3D+%27open%27+OR+Status+%3D+%27new%27%29&Format=&HideResults=0&Rows=50&Page=1&OrderBy=id&Order=DESC&TicketsRefreshInterval=30")
    End Sub

    Private Sub btnLaunchEditor_Click(sender As Object, e As RibbonControlEventArgs) Handles btnLaunchEditor.Click
        If Dir("C:\Program Files\BTC Template Editor\TemplateEditor.exe") <> "" Then
            System.Diagnostics.Process.Start("C:\Program Files\BTC Template Editor\TemplateEditor.exe")
        Else
            MessageBox.Show("Template Editor is not installed on this computer. Please contact the Cheese, please.", "Cheese, please", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
        End If
    End Sub

End Class

