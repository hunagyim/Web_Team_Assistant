﻿Partial Class MyEmailsRibbon
    Inherits Microsoft.Office.Tools.Ribbon.RibbonBase

    <System.Diagnostics.DebuggerNonUserCode()> _
   Public Sub New(ByVal container As System.ComponentModel.IContainer)
        MyClass.New()

        'Required for Windows.Forms Class Composition Designer support
        If (container IsNot Nothing) Then
            container.Add(Me)
        End If

    End Sub

    <System.Diagnostics.DebuggerNonUserCode()> _
    Public Sub New()
        MyBase.New(Globals.Factory.GetRibbonFactory())

        'This call is required by the Component Designer.
        InitializeComponent()

    End Sub

    'Component overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Component Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Component Designer
    'It can be modified using the Component Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Tab1 = Me.Factory.CreateRibbonTab
        Me.grpWTAReadPane = Me.Factory.CreateRibbonGroup
        Me.BGReplyMail = Me.Factory.CreateRibbonButtonGroup
        Me.ButtonGroup1 = Me.Factory.CreateRibbonButtonGroup
        Me.btnReply = Me.Factory.CreateRibbonButton
        Me.btnReplyAll = Me.Factory.CreateRibbonButton
        Me.btnForward = Me.Factory.CreateRibbonButton
        Me.btnTake = Me.Factory.CreateRibbonButton
        Me.btnClear = Me.Factory.CreateRibbonButton
        Me.Tab1.SuspendLayout()
        Me.grpWTAReadPane.SuspendLayout()
        Me.BGReplyMail.SuspendLayout()
        Me.ButtonGroup1.SuspendLayout()
        '
        'Tab1
        '
        Me.Tab1.ControlId.ControlIdType = Microsoft.Office.Tools.Ribbon.RibbonControlIdType.Office
        Me.Tab1.ControlId.OfficeId = "TabReadMessage"
        Me.Tab1.Groups.Add(Me.grpWTAReadPane)
        Me.Tab1.Label = "TabReadMessage"
        Me.Tab1.Name = "Tab1"
        '
        'grpWTAReadPane
        '
        Me.grpWTAReadPane.Items.Add(Me.BGReplyMail)
        Me.grpWTAReadPane.Items.Add(Me.ButtonGroup1)
        Me.grpWTAReadPane.Label = "Web Team Assistant"
        Me.grpWTAReadPane.Name = "grpWTAReadPane"
        Me.grpWTAReadPane.Position = Me.Factory.RibbonPosition.BeforeOfficeId("GroupRespond")
        '
        'BGReplyMail
        '
        Me.BGReplyMail.Items.Add(Me.btnReply)
        Me.BGReplyMail.Items.Add(Me.btnReplyAll)
        Me.BGReplyMail.Items.Add(Me.btnForward)
        Me.BGReplyMail.Name = "BGReplyMail"
        '
        'ButtonGroup1
        '
        Me.ButtonGroup1.Items.Add(Me.btnTake)
        Me.ButtonGroup1.Items.Add(Me.btnClear)
        Me.ButtonGroup1.Name = "ButtonGroup1"
        '
        'btnReply
        '
        Me.btnReply.Image = Global.Web_Team_Assistant.My.Resources.Resources.reply_to_v4
        Me.btnReply.Label = "Reply"
        Me.btnReply.Name = "btnReply"
        Me.btnReply.ShowImage = True
        '
        'btnReplyAll
        '
        Me.btnReplyAll.Image = Global.Web_Team_Assistant.My.Resources.Resources.reply_to_all_v3
        Me.btnReplyAll.Label = "Reply All"
        Me.btnReplyAll.Name = "btnReplyAll"
        Me.btnReplyAll.ShowImage = True
        '
        'btnForward
        '
        Me.btnForward.Image = Global.Web_Team_Assistant.My.Resources.Resources.buzz_forward_icon1
        Me.btnForward.Label = "Forward"
        Me.btnForward.Name = "btnForward"
        Me.btnForward.ShowImage = True
        '
        'btnTake
        '
        Me.btnTake.Image = Global.Web_Team_Assistant.My.Resources.Resources.assignToMev1
        Me.btnTake.Label = "Assign to me"
        Me.btnTake.Name = "btnTake"
        Me.btnTake.ShowImage = True
        '
        'btnClear
        '
        Me.btnClear.Image = Global.Web_Team_Assistant.My.Resources.Resources.clearv1
        Me.btnClear.Label = "Clear"
        Me.btnClear.Name = "btnClear"
        Me.btnClear.ShowImage = True
        '
        'MyEmailsRibbon
        '
        Me.Name = "MyEmailsRibbon"
        Me.RibbonType = "Microsoft.Outlook.Mail.Read, Microsoft.Outlook.Post.Read"
        Me.Tabs.Add(Me.Tab1)
        Me.Tab1.ResumeLayout(False)
        Me.Tab1.PerformLayout()
        Me.grpWTAReadPane.ResumeLayout(False)
        Me.grpWTAReadPane.PerformLayout()
        Me.BGReplyMail.ResumeLayout(False)
        Me.BGReplyMail.PerformLayout()
        Me.ButtonGroup1.ResumeLayout(False)
        Me.ButtonGroup1.PerformLayout()

    End Sub

    Friend WithEvents Tab1 As Microsoft.Office.Tools.Ribbon.RibbonTab
    Friend WithEvents grpWTAReadPane As Microsoft.Office.Tools.Ribbon.RibbonGroup
    Friend WithEvents BGReplyMail As Microsoft.Office.Tools.Ribbon.RibbonButtonGroup
    Friend WithEvents btnReply As Microsoft.Office.Tools.Ribbon.RibbonButton
    Friend WithEvents btnReplyAll As Microsoft.Office.Tools.Ribbon.RibbonButton
    Friend WithEvents btnTake As Microsoft.Office.Tools.Ribbon.RibbonButton
    Friend WithEvents btnClear As Microsoft.Office.Tools.Ribbon.RibbonButton
    Friend WithEvents btnForward As Microsoft.Office.Tools.Ribbon.RibbonButton
    Friend WithEvents ButtonGroup1 As Microsoft.Office.Tools.Ribbon.RibbonButtonGroup
End Class

Partial Class ThisRibbonCollection

    <System.Diagnostics.DebuggerNonUserCode()> _
    Friend ReadOnly Property MyEmailsRibbon() As MyEmailsRibbon
        Get
            Return Me.GetRibbon(Of MyEmailsRibbon)()
        End Get
    End Property
End Class
