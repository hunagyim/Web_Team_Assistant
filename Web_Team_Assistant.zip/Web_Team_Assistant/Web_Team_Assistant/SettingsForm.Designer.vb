﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class SettingsForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnUpdate = New System.Windows.Forms.Button()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.grpEIN = New System.Windows.Forms.GroupBox()
        Me.txtEmail = New System.Windows.Forms.TextBox()
        Me.txtEIN = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.grpDetails = New System.Windows.Forms.GroupBox()
        Me.txtHash3 = New System.Windows.Forms.TextBox()
        Me.txtHash2 = New System.Windows.Forms.TextBox()
        Me.txtHash4 = New System.Windows.Forms.TextBox()
        Me.txtHash1 = New System.Windows.Forms.TextBox()
        Me.txtRole = New System.Windows.Forms.TextBox()
        Me.txtBoat = New System.Windows.Forms.TextBox()
        Me.txtLastName = New System.Windows.Forms.TextBox()
        Me.txtFirstName = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.btnOK = New System.Windows.Forms.Button()
        Me.grpTemplates = New System.Windows.Forms.GroupBox()
        Me.cbxTemplate = New System.Windows.Forms.ComboBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.cbxPwTemplate = New System.Windows.Forms.ComboBox()
        Me.grpEIN.SuspendLayout()
        Me.grpDetails.SuspendLayout()
        Me.grpTemplates.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnUpdate
        '
        Me.btnUpdate.Location = New System.Drawing.Point(218, 477)
        Me.btnUpdate.Name = "btnUpdate"
        Me.btnUpdate.Size = New System.Drawing.Size(75, 23)
        Me.btnUpdate.TabIndex = 0
        Me.btnUpdate.Text = "Update"
        Me.btnUpdate.UseVisualStyleBackColor = True
        '
        'btnCancel
        '
        Me.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnCancel.Location = New System.Drawing.Point(420, 477)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(75, 23)
        Me.btnCancel.TabIndex = 0
        Me.btnCancel.Text = "Close"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'grpEIN
        '
        Me.grpEIN.Controls.Add(Me.txtEmail)
        Me.grpEIN.Controls.Add(Me.txtEIN)
        Me.grpEIN.Controls.Add(Me.Label2)
        Me.grpEIN.Controls.Add(Me.Label1)
        Me.grpEIN.Location = New System.Drawing.Point(13, 16)
        Me.grpEIN.Name = "grpEIN"
        Me.grpEIN.Size = New System.Drawing.Size(488, 86)
        Me.grpEIN.TabIndex = 2
        Me.grpEIN.TabStop = False
        Me.grpEIN.Text = "EIN and email address"
        '
        'txtEmail
        '
        Me.txtEmail.Enabled = False
        Me.txtEmail.Location = New System.Drawing.Point(126, 51)
        Me.txtEmail.Name = "txtEmail"
        Me.txtEmail.Size = New System.Drawing.Size(356, 20)
        Me.txtEmail.TabIndex = 1
        '
        'txtEIN
        '
        Me.txtEIN.Enabled = False
        Me.txtEIN.Location = New System.Drawing.Point(126, 22)
        Me.txtEIN.Name = "txtEIN"
        Me.txtEIN.Size = New System.Drawing.Size(356, 20)
        Me.txtEIN.TabIndex = 1
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(20, 55)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(88, 13)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "My email address"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(20, 26)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(80, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "My EIN number"
        '
        'grpDetails
        '
        Me.grpDetails.Controls.Add(Me.txtHash3)
        Me.grpDetails.Controls.Add(Me.txtHash2)
        Me.grpDetails.Controls.Add(Me.txtHash4)
        Me.grpDetails.Controls.Add(Me.txtHash1)
        Me.grpDetails.Controls.Add(Me.txtRole)
        Me.grpDetails.Controls.Add(Me.txtBoat)
        Me.grpDetails.Controls.Add(Me.txtLastName)
        Me.grpDetails.Controls.Add(Me.txtFirstName)
        Me.grpDetails.Controls.Add(Me.Label10)
        Me.grpDetails.Controls.Add(Me.Label9)
        Me.grpDetails.Controls.Add(Me.Label6)
        Me.grpDetails.Controls.Add(Me.Label8)
        Me.grpDetails.Controls.Add(Me.Label5)
        Me.grpDetails.Controls.Add(Me.Label7)
        Me.grpDetails.Controls.Add(Me.Label4)
        Me.grpDetails.Controls.Add(Me.Label3)
        Me.grpDetails.Location = New System.Drawing.Point(13, 106)
        Me.grpDetails.Name = "grpDetails"
        Me.grpDetails.Size = New System.Drawing.Size(488, 268)
        Me.grpDetails.TabIndex = 3
        Me.grpDetails.TabStop = False
        Me.grpDetails.Text = "My Details"
        '
        'txtHash3
        '
        Me.txtHash3.Enabled = False
        Me.txtHash3.Location = New System.Drawing.Point(126, 205)
        Me.txtHash3.Name = "txtHash3"
        Me.txtHash3.Size = New System.Drawing.Size(356, 20)
        Me.txtHash3.TabIndex = 5
        '
        'txtHash2
        '
        Me.txtHash2.Enabled = False
        Me.txtHash2.Location = New System.Drawing.Point(126, 174)
        Me.txtHash2.Name = "txtHash2"
        Me.txtHash2.Size = New System.Drawing.Size(356, 20)
        Me.txtHash2.TabIndex = 4
        '
        'txtHash4
        '
        Me.txtHash4.Enabled = False
        Me.txtHash4.Location = New System.Drawing.Point(126, 236)
        Me.txtHash4.Name = "txtHash4"
        Me.txtHash4.Size = New System.Drawing.Size(356, 20)
        Me.txtHash4.TabIndex = 3
        '
        'txtHash1
        '
        Me.txtHash1.Enabled = False
        Me.txtHash1.Location = New System.Drawing.Point(126, 143)
        Me.txtHash1.Name = "txtHash1"
        Me.txtHash1.Size = New System.Drawing.Size(356, 20)
        Me.txtHash1.TabIndex = 2
        '
        'txtRole
        '
        Me.txtRole.Enabled = False
        Me.txtRole.Location = New System.Drawing.Point(126, 112)
        Me.txtRole.Name = "txtRole"
        Me.txtRole.Size = New System.Drawing.Size(356, 20)
        Me.txtRole.TabIndex = 1
        '
        'txtBoat
        '
        Me.txtBoat.Enabled = False
        Me.txtBoat.Location = New System.Drawing.Point(126, 81)
        Me.txtBoat.Name = "txtBoat"
        Me.txtBoat.Size = New System.Drawing.Size(356, 20)
        Me.txtBoat.TabIndex = 1
        '
        'txtLastName
        '
        Me.txtLastName.Enabled = False
        Me.txtLastName.Location = New System.Drawing.Point(126, 50)
        Me.txtLastName.Name = "txtLastName"
        Me.txtLastName.Size = New System.Drawing.Size(356, 20)
        Me.txtLastName.TabIndex = 1
        '
        'txtFirstName
        '
        Me.txtFirstName.Enabled = False
        Me.txtFirstName.Location = New System.Drawing.Point(126, 19)
        Me.txtFirstName.Name = "txtFirstName"
        Me.txtFirstName.Size = New System.Drawing.Size(356, 20)
        Me.txtFirstName.TabIndex = 1
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(20, 240)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(48, 13)
        Me.Label10.TabIndex = 0
        Me.Label10.Text = "Hash #4"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(20, 209)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(48, 13)
        Me.Label9.TabIndex = 0
        Me.Label9.Text = "Hash #3"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(20, 116)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(46, 13)
        Me.Label6.TabIndex = 0
        Me.Label6.Text = "My Role"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(20, 178)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(48, 13)
        Me.Label8.TabIndex = 0
        Me.Label8.Text = "Hash #2"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(20, 85)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(47, 13)
        Me.Label5.TabIndex = 0
        Me.Label5.Text = "BoaT ID"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(20, 147)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(48, 13)
        Me.Label7.TabIndex = 0
        Me.Label7.Text = "Hash #1"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(20, 54)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(58, 13)
        Me.Label4.TabIndex = 0
        Me.Label4.Text = "Last Name"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(20, 23)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(55, 13)
        Me.Label3.TabIndex = 0
        Me.Label3.Text = "First name"
        '
        'btnOK
        '
        Me.btnOK.Enabled = False
        Me.btnOK.Location = New System.Drawing.Point(13, 477)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(75, 23)
        Me.btnOK.TabIndex = 0
        Me.btnOK.Text = "OK"
        Me.btnOK.UseVisualStyleBackColor = True
        '
        'grpTemplates
        '
        Me.grpTemplates.Controls.Add(Me.cbxPwTemplate)
        Me.grpTemplates.Controls.Add(Me.Label12)
        Me.grpTemplates.Controls.Add(Me.cbxTemplate)
        Me.grpTemplates.Controls.Add(Me.Label11)
        Me.grpTemplates.Location = New System.Drawing.Point(13, 380)
        Me.grpTemplates.Name = "grpTemplates"
        Me.grpTemplates.Size = New System.Drawing.Size(488, 86)
        Me.grpTemplates.TabIndex = 4
        Me.grpTemplates.TabStop = False
        Me.grpTemplates.Text = "Templates"
        '
        'cbxTemplate
        '
        Me.cbxTemplate.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbxTemplate.FormattingEnabled = True
        Me.cbxTemplate.Location = New System.Drawing.Point(126, 19)
        Me.cbxTemplate.Name = "cbxTemplate"
        Me.cbxTemplate.Size = New System.Drawing.Size(176, 21)
        Me.cbxTemplate.TabIndex = 1
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(20, 23)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(84, 13)
        Me.Label11.TabIndex = 0
        Me.Label11.Text = "Default template"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(20, 54)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(100, 13)
        Me.Label12.TabIndex = 2
        Me.Label12.Text = "Password Template"
        '
        'cbxPwTemplate
        '
        Me.cbxPwTemplate.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbxPwTemplate.FormattingEnabled = True
        Me.cbxPwTemplate.Location = New System.Drawing.Point(126, 50)
        Me.cbxPwTemplate.Name = "cbxPwTemplate"
        Me.cbxPwTemplate.Size = New System.Drawing.Size(176, 21)
        Me.cbxPwTemplate.TabIndex = 3
        '
        'SettingsForm
        '
        Me.AcceptButton = Me.btnOK
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.btnCancel
        Me.ClientSize = New System.Drawing.Size(515, 509)
        Me.Controls.Add(Me.grpTemplates)
        Me.Controls.Add(Me.grpDetails)
        Me.Controls.Add(Me.grpEIN)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnOK)
        Me.Controls.Add(Me.btnUpdate)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "SettingsForm"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Settings"
        Me.grpEIN.ResumeLayout(False)
        Me.grpEIN.PerformLayout()
        Me.grpDetails.ResumeLayout(False)
        Me.grpDetails.PerformLayout()
        Me.grpTemplates.ResumeLayout(False)
        Me.grpTemplates.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents btnUpdate As System.Windows.Forms.Button
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents grpEIN As System.Windows.Forms.GroupBox
    Friend WithEvents txtEmail As System.Windows.Forms.TextBox
    Friend WithEvents txtEIN As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents grpDetails As System.Windows.Forms.GroupBox
    Friend WithEvents btnOK As System.Windows.Forms.Button
    Friend WithEvents txtRole As System.Windows.Forms.TextBox
    Friend WithEvents txtBoat As System.Windows.Forms.TextBox
    Friend WithEvents txtLastName As System.Windows.Forms.TextBox
    Friend WithEvents txtFirstName As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtHash3 As System.Windows.Forms.TextBox
    Friend WithEvents txtHash2 As System.Windows.Forms.TextBox
    Friend WithEvents txtHash4 As System.Windows.Forms.TextBox
    Friend WithEvents txtHash1 As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents grpTemplates As System.Windows.Forms.GroupBox
    Friend WithEvents cbxTemplate As System.Windows.Forms.ComboBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents cbxPwTemplate As System.Windows.Forms.ComboBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
End Class
