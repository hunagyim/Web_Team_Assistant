﻿Imports Shell32
Imports SHDocVw
Imports Word = Microsoft.Office.Interop.Word
Imports Microsoft.VisualStudio.TestTools.UnitTesting
Imports System.Windows.Forms

Module Module_MyReplySubs

    Private WithEvents olReply As Outlook.MailItem
    Private WithEvents olForward As Outlook.MailItem
    Private strFirstName As String = "FIRSTNAME"
    Private strRIMS As String = "RIMS"
    Private olMailReplyOrigBody As String = ""
    Private olMailReply As Object = Nothing
    Private olMailForward As Object = Nothing
    Private isReply As Boolean = False
    Private myagentdata As New UCS_Agent
    Private haverims As Boolean = False
    Public olEmailsDoneFldr As Outlook.MAPIFolder
    Public olInboxFldr As Microsoft.Exchange.WebServices.Data.Folder

    Public Sub MyReply()

        Call CustomReply("Reply")

    End Sub

    Public Sub MyReplyAll()

        Call CustomReply("Reply All")

    End Sub



    Public Sub ForwardMail()


        Dim olApp As New Outlook.Application
        Dim tmpStatus As MailStatus
        Dim myItem As Object

        Dim fwdTo As String = ""
        Dim strTemplate As String = ""
        Dim strPath As String = ""
        Dim strBody As String = ""

        myagentdata = GetDataFromReg()

        ' Check how many emails are selected, cannot reply to more than 1 mail
        If olApp.ActiveExplorer.Selection.Count <> 1 Then
            If olApp.ActiveExplorer.Selection.Count = 0 Then
                MessageBox.Show("Before forwarding an email, you have to select one first!", "No email is selected", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Exit Sub
            End If
            MessageBox.Show("Please select only one email, before forwarding.", "Too many emails are selected", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If

        'Select Forward recipient
        Dim frmFwd As New ForwardMailForm
        If frmFwd.ShowDialog = Windows.Forms.DialogResult.Cancel Then
            Exit Sub
        End If

        ' Grab the selected mail and it's status
        myItem = GetCurrentItem()

        tmpStatus = GetStatus(myItem)

        ' Check the status of the mail, we cannot reply to everything
        Select Case tmpStatus
            Case MailStatus.NA
                MessageBox.Show("Cannot retrieve the status of the email!", "Status error", _
                                MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            Case MailStatus.NotMine, MailStatus.NotTaken
                MessageBox.Show("Please assign the ticket to yourself before you forward it.", "Email is not under your name", _
                                MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Exit Sub
        End Select

        'locate the forward template(s)
        strPath = CStr(Environ("USERPROFILE")) & "\Documents\MyTemplates\ForwardTo\Default.htm"

        'Handle radiobutton selection
        If frmFwd.radioMM.Checked Then
            fwdTo = "btc.meetme@bt.com"
        ElseIf frmFwd.radioVideo.Checked Then
            fwdTo = "btcreservations@conferencesetup.com"
        ElseIf frmFwd.radioEvents.Checked Then
            fwdTo = "event.management@bt.com"
        ElseIf frmFwd.radioSales.Checked Then
            fwdTo = "btc.sales@bt.com"
        Else
            fwdTo = ""
        End If

        ' Remove the BOAT ID from the subject
        Call SetStatus(myItem, MailStatus.NotTaken)

        olForward = myItem.Forward

        ' Remove the BOAT ID from the subject
        Call SetStatus(myItem, MailStatus.TakenNFA)

        ' Store the original email
        olMailForward = myItem

        'Add the correct recipient
        olForward.To = fwdTo
        olForward.CC = myItem.SenderEmailAddress
        olForward.Recipients.ResolveAll()

        'Create the body
        If Dir(strPath) <> "" Then
            ' Replace agent details in signature
            strBody = GetSignature(strPath & strTemplate)
            strBody = Replace(strBody, "%FULLNAME", myagentdata.FullName)
            olForward.Display()
            Call DeleteSignature(olForward)
        Else
            strBody = ""
            olForward.Display()
        End If

        olForward.HTMLBody = strBody & olForward.HTMLBody

    End Sub

    Private Sub CustomReply(mode As String)

        Dim myItem As Object
        Dim olApp As New Outlook.Application

        Dim tmpStatus As MailStatus
        Dim strBody As String
        Dim strReply As String = ""

        myagentdata = GetDataFromReg()

        ' Check that another reply window is opened or not
        If isReply Then
            MessageBox.Show("You can only reply to one mail at a time.", "A reply window is already opened", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If

        ' Check how many emails are selected, cannot reply to more than 1 mail
        If olApp.ActiveExplorer.Selection.Count <> 1 Then
            If olApp.ActiveExplorer.Selection.Count = 0 Then
                MessageBox.Show("Before replying to an email, you have to select one first!", "No email selected", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Exit Sub
            End If
            MessageBox.Show("Please select only one email, before replying.", "Too many emails are selected", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If

        ' Grab the selected mail and it's status
        myItem = GetCurrentItem()

        tmpStatus = GetStatus(myItem)

        ' Check the status of the mail, we cannot reply to everything
        Select Case tmpStatus
            Case MailStatus.NA
                MessageBox.Show("Cannot read status of the email.", "Status error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            Case MailStatus.NotMine
                MessageBox.Show("You cannot reply to your colleague's email.", "Not your email", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Exit Sub
            Case MailStatus.NotTaken
                MessageBox.Show("This email is not under your name. To reply this email, first take it under your name.", _
                                "Email is not taken", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Exit Sub
            Case MailStatus.TakenNFA
                MessageBox.Show("If no further action is required, please do not reply to this email.", "No further action", _
                                MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Exit Sub
        End Select

        haverims = True
        ' Check if there is a RIMS window opened somewhere
        strBody = GetBodyString()

        'haverims = True
        If strBody = "" Then
            haverims = False
        End If

        If InStr(strBody, "Incident #: ") = 0 Or InStr(strBody, "Incident #: ") = 0 Or _
                InStr(strBody, "First Name: ") = 0 Then
            haverims = False
        End If

        olMailReply = myItem

        ' Remove the BOAT ID from the subject
        Call SetStatus(myItem, MailStatus.NotTaken)

        ' Reply or Reply to All, depending on the mode (parameter)
        If mode = "Reply" Then
            olReply = myItem.Reply
        Else
            olReply = myItem.ReplyAll
        End If
        ' Add the BOAT ID back to the subject of the original mail
        Call SetStatus(myItem, tmpStatus)

        ' Remove btc.advanced.services@bt.com from the recipients list
        For i = olReply.Recipients.Count To 1 Step -1
            Dim r As Outlook.Recipient = olReply.Recipients.Item(i)
            If r.Name = "BTC ADVANCED SERVICES G" Then
                olReply.Recipients.Remove(i)
            Else
                If Not r.Resolved Then
                    r.Resolve()
                End If
            End If
        Next i


        ' If a RIMS window is opened, then fill the reply mail with the default template
        Dim strTempName As String = GetSetting("UCS Assign Mails", "UserDetails", "DefaultTemplate", "")

        If haverims = True Then
            Dim strPwTempName As String = GetSetting("UCS Assign Mails", "UserDetails", "DefaultPasswordTemplate", "")
            If InStr(UCase(olMailReply.Subject), "USER PASSWORD REQUEST") > 0 And strPwTempName <> "(none)" And _
                    Not String.IsNullOrEmpty(strPwTempName) Then
                strReply = GetReplyBodyText(strBody, strPwTempName)
            Else
                If Not String.IsNullOrEmpty(strTempName) And strTempName <> "(none)" Then
                    strReply = GetReplyBodyText(strBody, strTempName)
                End If
            End If
            olReply.Display()
            Call DeleteSignature(olReply)
            olMailReplyOrigBody = olReply.HTMLBody
            olReply.HTMLBody = strReply & olMailReplyOrigBody

            isReply = True
        Else
            olReply.Display()
            olMailReplyOrigBody = olReply.HTMLBody
            isReply = True
        End If

    End Sub

    Private Function GetBodyString() As String

        Dim ShellWindows As New ShellWindows
        Dim doc As mshtml.HTMLDocument = Nothing
        Dim ie = New InternetExplorer
        Dim strResult As String = ""

        For Each ie In ShellWindows

            If InStr(ie.LocationURL, "rims.btci.com") > 0 And InStr(ie.LocationURL, myagentdata.Email) > 0 And _
                    InStr(ie.LocationURL, "rs_edit_incident") = 0 Then
                haverims = True
                doc = ie.Document
                strResult = doc.body.innerText
                Exit For
            End If
        Next ie
        Return strResult
    End Function

    Private Function GetReplyBodyText(BodyString As String, TemplateName As String) As String

        Dim strSignature As String = ""
        Dim strPath As String = ""
        Dim strTemplate As String = ""

        ' Get the RIMS number and the First name of customer from the Body
        strRIMS = Mid(BodyString, InStr(BodyString, "Incident #: ") + 12, InStr(BodyString, "Client ID:") - InStr(BodyString, "Incident #: ") - 14)
        strFirstName = Mid(BodyString, InStr(BodyString, "First Name: ") + 12, InStr(BodyString, "Last Name:") - InStr(BodyString, "First Name: ") - 14)

        ' Convert First name to proper case
        strFirstName = StrConv(strFirstName, VbStrConv.ProperCase)

        ' Set up the path and the name of the template file
        strPath = CStr(Environ("USERPROFILE")) & "\Documents\MyTemplates\"
        strTemplate = TemplateName & ".htm"

        If Dir(strPath & strTemplate) <> "" Then

            ' Replace customer details in the body of the template
            strSignature = GetSignature(strPath & strTemplate)
            strSignature &= vbLf & GetSignature(strPath & "MySignature.htm")
            strSignature = Replace(strSignature, "%CUSTOMER_FIRSTNAME", strFirstName)
            strSignature = Replace(strSignature, "%RIMSNUMBER", strRIMS)

            ' Replace agent details in signature
            strSignature = Replace(strSignature, "%FULLNAME", myagentdata.FullName)
            strSignature = Replace(strSignature, "%HASH1", myagentdata.Hash1)
            strSignature = Replace(strSignature, "%HASH2", myagentdata.Hash2)
            strSignature = Replace(strSignature, "%HASH3", myagentdata.Hash3)
            strSignature = Replace(strSignature, "%HASH4", myagentdata.Hash4)
            strSignature = Replace(strSignature, "%FIRST_NAME", myagentdata.FirstName)
            strSignature = Replace(strSignature, "%LAST_NAME", myagentdata.LastName)
            strSignature = Replace(strSignature, "%EMAIL", myagentdata.Email)
            strSignature = Replace(strSignature, "%IMAGE_PATH", Replace(strPath, "\", "/") & "Signature_Images")
        Else
            strSignature = ""
        End If

        Return strSignature
    End Function

    Public Sub ReplaceBodyText(TemplateName As String)


        Dim strSignature As String = ""
        Dim strPath As String = ""
        Dim strTemplate As String = ""
        Dim rimsdata As String = ""

        Dim BodyString As String = olReply.Body
        Dim BodyStringStartPos As Integer = 0

        'We do need the rims info, as we do not save it previously
        If strRIMS = "RIMS" Then
            rimsdata = GetBodyString()

            If Not String.IsNullOrEmpty(rimsdata) Then

                ' Get the RIMS number and the First name of customer from the Body
                strRIMS = Mid(rimsdata, InStr(rimsdata, "Incident #: ") + 12, InStr(rimsdata, "Client ID:") - InStr(rimsdata, "Incident #: ") - 14)
                strFirstName = Mid(rimsdata, InStr(rimsdata, "First Name: ") + 12, InStr(rimsdata, "Last Name:") - InStr(rimsdata, "First Name: ") - 14)

                ' Convert First name to proper case
                strFirstName = StrConv(strFirstName, VbStrConv.ProperCase)
            End If
        End If

        ' Set up the path and the name of the template file
        strPath = CStr(Environ("USERPROFILE")) & "\Documents\MyTemplates\"
        strTemplate = TemplateName & ".htm"

        If Dir(strPath & strTemplate) <> "" Then

            ' Replace customer details in the body of the template
            strSignature = GetSignature(strPath & strTemplate)
            strSignature &= vbLf & GetSignature(strPath & "MySignature.htm")
            strSignature = Replace(strSignature, "%CUSTOMER_FIRSTNAME", strFirstName)
            strSignature = Replace(strSignature, "%RIMSNUMBER", strRIMS)

            ' Replace agent details in signature
            strSignature = Replace(strSignature, "%FULLNAME", myagentdata.FullName)
            strSignature = Replace(strSignature, "%HASH1", myagentdata.Hash1)
            strSignature = Replace(strSignature, "%HASH2", myagentdata.Hash2)
            strSignature = Replace(strSignature, "%HASH3", myagentdata.Hash3)
            strSignature = Replace(strSignature, "%HASH4", myagentdata.Hash4)
            strSignature = Replace(strSignature, "%FIRST_NAME", myagentdata.FirstName)
            strSignature = Replace(strSignature, "%LAST_NAME", myagentdata.LastName)
            strSignature = Replace(strSignature, "%EMAIL", myagentdata.Email)
            strSignature = Replace(strSignature, "%IMAGE_PATH", Replace(strPath, "\", "/") & "Signature_Images")
        Else
            Exit Sub
        End If

        olReply.HTMLBody = strSignature & olMailReplyOrigBody
        olReply.Save()

    End Sub

    Private Function GetSignature(fPath As String) As String

        Dim fso As Object
        Dim TSet As Object

        fso = CreateObject("Scripting.FileSystemObject")
        TSet = fso.GetFile(fPath).OpenAsTextStream(1, -2)

        GetSignature = TSet.readall
        TSet.Close()

    End Function

    Private Sub DeleteSignature(msg As Outlook.MailItem)

        Dim objDoc As Word.Document
        Dim objBkm As Word.Bookmark

        Try
            objDoc = msg.GetInspector.WordEditor
            If objDoc.Bookmarks.Exists("_MailAutoSig") = True Then
                objBkm = objDoc.Bookmarks("_MailAutoSig")
                If Not IsNothing(objBkm) Then
                    objBkm.Select()
                    With objDoc.Windows(1).Selection
                        .Delete()
                        .HomeKey(Word.WdUnits.wdStory)
                    End With
                End If
            End If
        Catch ex As Exception
            MessageBox.Show("Cannot read email body : & " & vbCrLf & ex.Message, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        objDoc = Nothing
        objBkm = Nothing

    End Sub

    Private Sub ForwardSent(ByRef cancel As Boolean) Handles olForward.Send

        If Not IsNothing(olEmailsDoneFldr) Then
            olMailForward.Move(olEmailsDoneFldr)
        End If

    End Sub

    Private Sub ReplySent(ByRef cancel As Boolean) Handles olReply.Send

        Dim frmReplyForm As New ReplyMailForm
        Dim olApp As New Outlook.Application
        Dim olInsp As Outlook.Inspector

        If GetStatus(olMailReply) = MailStatus.Taken Then
            'Code when it is only taken, show form
            If frmReplyForm.ShowDialog() = Windows.Forms.DialogResult.Cancel Then
                cancel = True
                Exit Sub
            End If

            If frmReplyForm.rbtnREQ.Checked Then
                SetStatus(olMailReply, MailStatus.TakenREQ)
            Else
                SetStatus(olMailReply, MailStatus.TakenINC)
            End If
        End If

        olMailReply.UnRead = False

        If Not IsNothing(olEmailsDoneFldr) Then
            olMailReply.Move(olEmailsDoneFldr)
        End If

        For Each olInsp In olApp.Inspectors

            If olInsp.CurrentItem.Subject = olMailReply.Subject Then
                olInsp.Close(Outlook.OlInspectorClose.olSave)
                Exit For
            End If

        Next
    End Sub

    'Cleanup process for closing
    Private Sub SetReplyToNothing(ByRef cancel As Boolean) Handles olReply.Close
        olMailReply = Nothing
        isReply = False
        strRIMS = "RIMS"
        strFirstName = "FirstName"
        olMailReplyOrigBody = ""
    End Sub

End Module
