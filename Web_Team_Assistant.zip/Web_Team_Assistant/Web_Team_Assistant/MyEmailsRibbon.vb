﻿Imports Microsoft.Office.Tools.Ribbon
Imports System.Windows.Forms

Public Class MyEmailsRibbon

    Private Sub MyEmailsRibbon_Load(ByVal sender As System.Object, ByVal e As RibbonUIEventArgs) Handles MyBase.Load

    End Sub

    Private Sub btnReply_Click(sender As Object, e As RibbonControlEventArgs) Handles btnReply.Click
        Call MyReply()
    End Sub

    Private Sub btnReplyAll_Click(sender As Object, e As RibbonControlEventArgs) Handles btnReplyAll.Click
        Call MyReplyAll()
    End Sub

    Private Sub btnTake_Click(sender As Object, e As RibbonControlEventArgs) Handles btnTake.Click

        Dim olItem As Object = GetCurrentItem()

        If GetStatus(olItem) = MailStatus.NA Then Exit Sub
        If GetStatus(olItem) = MailStatus.Taken Then
            MessageBox.Show("This email is already under your name : " & olItem.Subject, "Already taken", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        Else
            Call SetStatus(olItem, MailStatus.Taken)
        End If

    End Sub

    Private Sub btnClear_Click(sender As Object, e As RibbonControlEventArgs) Handles btnClear.Click
        Dim olItem As Object = GetCurrentItem()
        Call SetStatus(olItem, MailStatus.NotTaken)
    End Sub

    Private Sub btnForward_Click(sender As Object, e As RibbonControlEventArgs) Handles btnForward.Click
        Call ForwardMail()
    End Sub
End Class
