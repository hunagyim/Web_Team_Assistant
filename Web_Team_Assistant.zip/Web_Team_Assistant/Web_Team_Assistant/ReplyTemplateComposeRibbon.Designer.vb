﻿Partial Class ReplyTemplateComposeRibbon
    Inherits Microsoft.Office.Tools.Ribbon.RibbonBase

    <System.Diagnostics.DebuggerNonUserCode()> _
   Public Sub New(ByVal container As System.ComponentModel.IContainer)
        MyClass.New()

        'Required for Windows.Forms Class Composition Designer support
        If (container IsNot Nothing) Then
            container.Add(Me)
        End If

    End Sub

    <System.Diagnostics.DebuggerNonUserCode()> _
    Public Sub New()
        MyBase.New(Globals.Factory.GetRibbonFactory())

        'This call is required by the Component Designer.
        InitializeComponent()

    End Sub

    'Component overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Component Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Component Designer
    'It can be modified using the Component Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Tab1 = Me.Factory.CreateRibbonTab
        Me.grpReplyTemplate = Me.Factory.CreateRibbonGroup
        Me.ddlTemplates = Me.Factory.CreateRibbonDropDown
        Me.Tab1.SuspendLayout()
        Me.grpReplyTemplate.SuspendLayout()
        '
        'Tab1
        '
        Me.Tab1.ControlId.ControlIdType = Microsoft.Office.Tools.Ribbon.RibbonControlIdType.Office
        Me.Tab1.ControlId.OfficeId = "TabNewMailMessage"
        Me.Tab1.Groups.Add(Me.grpReplyTemplate)
        Me.Tab1.Label = "TabNewMailMessage"
        Me.Tab1.Name = "Tab1"
        Me.Tab1.Position = Me.Factory.RibbonPosition.BeforeOfficeId("GroupNames")
        '
        'grpReplyTemplate
        '
        Me.grpReplyTemplate.Items.Add(Me.ddlTemplates)
        Me.grpReplyTemplate.Label = "Web Team Assistant"
        Me.grpReplyTemplate.Name = "grpReplyTemplate"
        Me.grpReplyTemplate.Position = Me.Factory.RibbonPosition.BeforeOfficeId("GroupBasicText")
        '
        'ddlTemplates
        '
        Me.ddlTemplates.Image = Global.Web_Team_Assistant.My.Resources.Resources.reply_templates
        Me.ddlTemplates.Label = "Reply with"
        Me.ddlTemplates.Name = "ddlTemplates"
        Me.ddlTemplates.ShowImage = True
        '
        'ReplyTemplateComposeRibbon
        '
        Me.Name = "ReplyTemplateComposeRibbon"
        Me.RibbonType = "Microsoft.Outlook.Mail.Compose"
        Me.Tabs.Add(Me.Tab1)
        Me.Tab1.ResumeLayout(False)
        Me.Tab1.PerformLayout()
        Me.grpReplyTemplate.ResumeLayout(False)
        Me.grpReplyTemplate.PerformLayout()

    End Sub

    Friend WithEvents Tab1 As Microsoft.Office.Tools.Ribbon.RibbonTab
    Friend WithEvents grpReplyTemplate As Microsoft.Office.Tools.Ribbon.RibbonGroup
    Friend WithEvents ddlTemplates As Microsoft.Office.Tools.Ribbon.RibbonDropDown
End Class

Partial Class ThisRibbonCollection

    <System.Diagnostics.DebuggerNonUserCode()> _
    Friend ReadOnly Property ReplyTemplateComposeRibbon() As ReplyTemplateComposeRibbon
        Get
            Return Me.GetRibbon(Of ReplyTemplateComposeRibbon)()
        End Get
    End Property
End Class
