﻿Imports System.Collections.Generic
Imports System.Net.Mail
Imports Microsoft.Office.Tools
Imports Office = Microsoft.Office.Core
Imports Outlook = Microsoft.Office.Interop.Outlook
Imports System.Windows.Forms

Public Class ThisAddIn

    Private menuBar As Office.CommandBar
    Private newMenuBar As Office.CommandBarPopup
    Private buttonOne As Office.CommandBarButton
    Private menuTag As String = "A unique tag"
    Private myagentdata As New UCS_Agent

    Private WithEvents Items As Outlook.Items

    Private Sub ThisAddIn_Startup() Handles Me.Startup

        Dim strBoat As String
        Dim outlookimg = My.Computer.Registry.GetValue("HKEY_CURRENT_USER\Software\Microsoft\Office\15.0\Outlook\options\mail", "Send Pictures With Document", Nothing)

        Items = Me.Application.GetNamespace("MAPI").Stores("BTC ADVANCED SERVICES G").GetRootFolder.Folders("Inbox").Items

        If outlookimg <> 1 Then
            My.Computer.Registry.SetValue("HKEY_CURRENT_USER\Software\Microsoft\Office\15.0\Outlook\options\mail", "Send Pictures With Document", 1)
        End If

        ' Check if registy entry exists or not
        strBoat = GetSetting("UCS Assign Mails", "UserDetails", "BoatID", "")
        If strBoat = "" Then
            If UpdateRegistry() = "NA" Then

                MessageBox.Show("ERROR WITH REGISTRY", "Registration error", MessageBoxButtons.OK, MessageBoxIcon.Error)

            End If
        End If

        ' Get the correct connection string for Access database
        ConnString = GetConnectionString("\\Hubufps02\roc\GCSO\Public\BTC\BTC applications\UCS_Agents.accdb")

        ' Store the Emails done folder in a public variable : olEmailsDoneFldr
        Call GetEmailsDoneFolder()

        ' Fill the dropdown list for TC with agents 
        Call FillTCDropDown()
    End Sub

    Private Sub NewEmail(ByVal item As Object) Handles Items.ItemAdd
        Dim FullName As String = ""
        Dim BodyString As String = item.body
        Dim minPos As Integer = 0
        Dim agentNum As Integer = 0
        myagentdata = GetDataFromReg()
        FullName = myagentdata.FullName

        For i = 0 To UBound(arrAgents) - 1
            If (minPos = 0 And InStr(BodyString, arrAgents(i)) > 0) Or _
                    (InStr(BodyString, arrAgents(i)) < minPos And InStr(BodyString, arrAgents(i)) > 0) Then

                minPos = InStr(BodyString, arrAgents(i))
                agentNum = i
            End If
        Next i

        'MsgBox("First agent in the mail is " & arrAgents(agentNum))

        If arrAgents(agentNum) = myagentdata.FullName Then
            Call SetStatus(item, MailStatus.Taken)
        End If

    End Sub

    Private Sub GetEmailsDoneFolder()
        Dim olApp As Outlook.Application
        Dim objNS As Outlook.NameSpace
        Dim olStore As Outlook.Store
        olApp = Me.Application
        Try
            objNS = olApp.GetNamespace("MAPI")

            olStore = objNS.Stores("BTC ADVANCED SERVICES G")

            ' set the Root folder as the Emails Done folder
            ' BTC ADVANCED SERVICES G - Inbox - Emails Done
            olEmailsDoneFldr = olStore.GetRootFolder.Folders("Inbox").Folders("Emails Done")

        Catch ex As Exception
            MessageBox.Show("Cannot locate the Emails Done folder! Please select it from the list.", "Emails done folder not found", _
                            MessageBoxButtons.OK, MessageBoxIcon.Warning)
            olEmailsDoneFldr = olApp.GetNamespace("MAPI").PickFolder

        End Try
    End Sub

    Private Function UpdateRegistry()

        Dim thisAgent As UCS_Agent

        thisAgent = GetAgentData(Environ("USERNAME"))
        If thisAgent.BoatID = "NA" Then
            Return "NA"  'should be "NA"
        Else
            SaveSetting("UCS Assign Mails", "UserDetails", "BoatID", thisAgent.BoatID)
            SaveSetting("UCS Assign Mails", "UserDetails", "Email", thisAgent.Email)
            SaveSetting("UCS Assign Mails", "UserDetails", "FirstName", thisAgent.FirstName)
            SaveSetting("UCS Assign Mails", "UserDetails", "LastName", thisAgent.LastName)
            SaveSetting("UCS Assign Mails", "UserDetails", "FullName", thisAgent.FullName)
            SaveSetting("UCS Assign Mails", "UserDetails", "Hash1", thisAgent.Hash1)
            SaveSetting("UCS Assign Mails", "UserDetails", "Hash2", thisAgent.Hash2)
            SaveSetting("UCS Assign Mails", "UserDetails", "Hash3", thisAgent.Hash3)
            SaveSetting("UCS Assign Mails", "UserDetails", "Hash4", thisAgent.Hash4)
            SaveSetting("UCS Assign Mails", "UserDetails", "Role", thisAgent.Role)
            Return thisAgent.BoatID
        End If

    End Function

End Class

