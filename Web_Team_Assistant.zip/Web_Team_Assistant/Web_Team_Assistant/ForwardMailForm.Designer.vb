﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ForwardMailForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.radioMM = New System.Windows.Forms.RadioButton()
        Me.radioVideo = New System.Windows.Forms.RadioButton()
        Me.radioSales = New System.Windows.Forms.RadioButton()
        Me.radioEvents = New System.Windows.Forms.RadioButton()
        Me.btnOK = New System.Windows.Forms.Button()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(12, 24)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(317, 20)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Please select a group to forward the mail to:"
        '
        'radioMM
        '
        Me.radioMM.AutoSize = True
        Me.radioMM.Location = New System.Drawing.Point(16, 67)
        Me.radioMM.Name = "radioMM"
        Me.radioMM.Size = New System.Drawing.Size(144, 17)
        Me.radioMM.TabIndex = 1
        Me.radioMM.TabStop = True
        Me.radioMM.Text = "To MeetMe Collaboration"
        Me.radioMM.UseVisualStyleBackColor = True
        '
        'radioVideo
        '
        Me.radioVideo.AutoSize = True
        Me.radioVideo.Location = New System.Drawing.Point(16, 166)
        Me.radioVideo.Name = "radioVideo"
        Me.radioVideo.Size = New System.Drawing.Size(133, 17)
        Me.radioVideo.TabIndex = 2
        Me.radioVideo.TabStop = True
        Me.radioVideo.Text = "To Video Reservations"
        Me.radioVideo.UseVisualStyleBackColor = True
        '
        'radioSales
        '
        Me.radioSales.AutoSize = True
        Me.radioSales.Location = New System.Drawing.Point(16, 99)
        Me.radioSales.Name = "radioSales"
        Me.radioSales.Size = New System.Drawing.Size(91, 17)
        Me.radioSales.TabIndex = 3
        Me.radioSales.TabStop = True
        Me.radioSales.Text = "To BTC Sales"
        Me.radioSales.UseVisualStyleBackColor = True
        '
        'radioEvents
        '
        Me.radioEvents.AutoSize = True
        Me.radioEvents.Location = New System.Drawing.Point(16, 131)
        Me.radioEvents.Name = "radioEvents"
        Me.radioEvents.Size = New System.Drawing.Size(74, 17)
        Me.radioEvents.TabIndex = 5
        Me.radioEvents.TabStop = True
        Me.radioEvents.Text = "To Events"
        Me.radioEvents.UseVisualStyleBackColor = True
        '
        'btnOK
        '
        Me.btnOK.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.btnOK.Location = New System.Drawing.Point(198, 67)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(114, 33)
        Me.btnOK.TabIndex = 6
        Me.btnOK.Text = "OK"
        Me.btnOK.UseVisualStyleBackColor = True
        '
        'btnCancel
        '
        Me.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnCancel.Location = New System.Drawing.Point(198, 150)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(114, 33)
        Me.btnCancel.TabIndex = 7
        Me.btnCancel.Text = "Cancel"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'ForwardMailForm
        '
        Me.AcceptButton = Me.btnOK
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.btnCancel
        Me.ClientSize = New System.Drawing.Size(340, 204)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnOK)
        Me.Controls.Add(Me.radioEvents)
        Me.Controls.Add(Me.radioSales)
        Me.Controls.Add(Me.radioVideo)
        Me.Controls.Add(Me.radioMM)
        Me.Controls.Add(Me.Label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "ForwardMailForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Forward Email"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents radioMM As System.Windows.Forms.RadioButton
    Friend WithEvents radioVideo As System.Windows.Forms.RadioButton
    Friend WithEvents radioSales As System.Windows.Forms.RadioButton
    Friend WithEvents radioEvents As System.Windows.Forms.RadioButton
    Friend WithEvents btnOK As System.Windows.Forms.Button
    Friend WithEvents btnCancel As System.Windows.Forms.Button
End Class
