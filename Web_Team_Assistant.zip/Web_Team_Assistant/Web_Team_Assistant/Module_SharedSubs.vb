﻿Imports System.Data
Imports Microsoft.Office.Tools.Ribbon
Imports System.Windows.Forms

Module Module_SharedSubs

    Public ConnString As String
    Public arrBoatIDs() As String
    Public arrAgents() As String


    Public Function GetCurrentItem() As Object

        Dim objApp As New Outlook.Application

        Try
            Select Case TypeName(objApp.ActiveWindow)
                Case "Explorer"
                    Return objApp.ActiveExplorer.Selection.Item(1)
                Case "Inspector"
                    Return objApp.ActiveInspector.CurrentItem
            End Select
        Catch ex As Exception
            MessageBox.Show(ex.Message, "An error has been occurred.", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
        objApp = Nothing
        Return Nothing

    End Function


    Function GetAgentData(strEIN As String) As UCS_Agent

        Dim tmp As New UCS_Agent
        Dim Access As New DBControl(ConnString)

        tmp.BoatID = "NA"

        Access.AddParam("@user", strEIN)
        Access.ExecQuery("SELECT * FROM AgentDetails WHERE EINnumber = @user")
        If Not String.IsNullOrEmpty(Access.Exception) Then
            MessageBox.Show("Cannot access database. Update failed" & vbCrLf & Access.Exception, "Connection error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return tmp
        End If

        If Access.RecordCount = 0 Then
            MessageBox.Show("Cannot find EIN number in database", "EIN number was not found in Database", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return tmp
        End If

        Dim R As DataRow = Access.DBDT.Rows(0)

        tmp.BoatID = R("BoatID")
        tmp.Email = R("Email")
        tmp.FirstName = R("FirstName")
        tmp.LastName = R("LastName")
        tmp.FullName = R("AgentName")
        tmp.Hash1 = R("Hash1")
        tmp.Hash2 = R("Hash2")
        tmp.Hash3 = R("Hash3")
        tmp.Hash4 = R("Hash4")
        tmp.Role = R("Role")


        Return tmp

    End Function

    Function GetDataFromReg() As UCS_Agent
        Dim tmp As New UCS_Agent

        tmp.BoatID = GetSetting("UCS Assign Mails", "UserDetails", "BoatID", "")
        tmp.Email = GetSetting("UCS Assign Mails", "UserDetails", "Email", "")
        tmp.FirstName = GetSetting("UCS Assign Mails", "UserDetails", "FirstName", "")
        tmp.LastName = GetSetting("UCS Assign Mails", "UserDetails", "LastName", "")
        tmp.FullName = GetSetting("UCS Assign Mails", "UserDetails", "FullName", "")
        tmp.Hash1 = GetSetting("UCS Assign Mails", "UserDetails", "Hash1", "")
        tmp.Hash2 = GetSetting("UCS Assign Mails", "UserDetails", "Hash2", "")
        tmp.Hash3 = GetSetting("UCS Assign Mails", "UserDetails", "Hash3", "")
        tmp.Hash4 = GetSetting("UCS Assign Mails", "UserDetails", "Hash4", "")
        tmp.Role = GetSetting("UCS Assign Mails", "UserDetails", "Role", "")

        Return tmp
    End Function

    Public Function ReAuthXL()

        Dim thisAgent As UCS_Agent

        thisAgent = GetAgentData(Environ("USERNAME"))
        If thisAgent.BoatID = "NA" Then
            Return "NA"  'should be "NA"
        Else
            SaveSetting("UCS Assign Mails", "UserDetails", "BoatID", thisAgent.BoatID)
            SaveSetting("UCS Assign Mails", "UserDetails", "Email", thisAgent.Email)
            SaveSetting("UCS Assign Mails", "UserDetails", "FirstName", thisAgent.FirstName)
            SaveSetting("UCS Assign Mails", "UserDetails", "LastName", thisAgent.LastName)
            SaveSetting("UCS Assign Mails", "UserDetails", "FullName", thisAgent.FullName)
            SaveSetting("UCS Assign Mails", "UserDetails", "Hash1", thisAgent.Hash1)
            SaveSetting("UCS Assign Mails", "UserDetails", "Hash2", thisAgent.Hash2)
            SaveSetting("UCS Assign Mails", "UserDetails", "Hash3", thisAgent.Hash3)
            SaveSetting("UCS Assign Mails", "UserDetails", "Hash4", thisAgent.Hash4)
            SaveSetting("UCS Assign Mails", "UserDetails", "Role", thisAgent.Role)

            Return thisAgent.BoatID
        End If

    End Function

    Public Function GetConnectionString(ByVal MyDB_path As String) As String

        Dim dbMaintPort As OleDb.OleDbConnection
        Dim ValidConnection As Boolean
        Dim finalConnection As String = ""
        Dim connStrings(5) As String
        connStrings(0) = "Provider=Microsoft.ACE.OLEDB.15.0;Data Source=" & MyDB_path
        connStrings(1) = "Provider=Microsoft.ACE.OLEDB.14.0;Data Source=" & MyDB_path
        connStrings(2) = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & MyDB_path
        connStrings(3) = "Provider=Microsoft.ACE.OLEDB.11.0;Data Source=" & MyDB_path
        connStrings(4) = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & MyDB_path

        ValidConnection = False
        For value As Integer = 0 To 4
            Try
                dbMaintPort = New OleDb.OleDbConnection(connStrings(value))
                dbMaintPort.Open()
                dbMaintPort.Close()

                ValidConnection = True
                finalConnection = connStrings(value)
            Catch
            End Try

            If ValidConnection Then
                Return finalConnection
            End If
        Next

        Return finalConnection

    End Function

    Public Sub FillTCDropDown()

        Dim strRole As String

        strRole = GetSetting("UCS Assign Mails", "UserDetails", "Role", "")

        If strRole <> "2" Then
            Call LoadAgents()
            Exit Sub
        End If


        Globals.Ribbons.Ribbon1.drpTeamCoord.Visible = True

        Dim Access As New DBControl(ConnString)
        Dim nItem As RibbonDropDownItem
        Dim counter As Integer = 0

        Access.ExecQuery("SELECT BoatID, AgentName FROM AgentDetails ORDER BY AgentName ASC")
        If Not String.IsNullOrEmpty(Access.Exception) Then
            MessageBox.Show("Cannot populate TC dropdown." & vbCrLf & Access.Exception, "Connection error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Globals.Ribbons.Ribbon1.drpTeamCoord.Enabled = False

            Exit Sub
        End If

        ReDim arrBoatIDs(Access.RecordCount)
        ReDim arrAgents(Access.RecordCount)

        nItem = Globals.Factory.GetRibbonFactory().CreateRibbonDropDownItem()
        nItem.Label = ""
        Globals.Ribbons.Ribbon1.drpTeamCoord.Items.Add(nItem)
        nItem = Nothing

        For Each row As DataRow In Access.DBDT.Rows
            arrBoatIDs(counter) = row("BoatID")
            arrAgents(counter) = row("AgentName")
            counter += 1
            nItem = Globals.Factory.GetRibbonFactory().CreateRibbonDropDownItem()
            nItem.Label = row("AgentName")
            Globals.Ribbons.Ribbon1.drpTeamCoord.Items.Add(nItem)
            nItem = Nothing
        Next


    End Sub

    ' Populate the arrays if agent is not TC
    Private Sub LoadAgents()

        Dim Access As New DBControl(ConnString)
        Dim counter As Integer = 0

        Access.ExecQuery("SELECT BoatID, AgentName FROM AgentDetails ORDER BY AgentName ASC")

        If Not String.IsNullOrEmpty(Access.Exception) Then
            MessageBox.Show("Cannot load the agent list." & vbCrLf & Access.Exception, "Connection error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End If

        ReDim arrBoatIDs(Access.RecordCount)
        ReDim arrAgents(Access.RecordCount)

        For Each row As DataRow In Access.DBDT.Rows
            arrBoatIDs(counter) = row("BoatID")
            arrAgents(counter) = row("AgentName")
            counter += 1
        Next

    End Sub

End Module
