﻿Imports Microsoft.Office.Tools.Ribbon
Imports Microsoft.Office.Interop.Outlook
Imports System.Windows.Forms
Imports System.IO

Public Class ReplyTemplateComposeRibbon

    Private Sub ddlTemplates_ItemsLoading(sender As Object, e As RibbonControlEventArgs) Handles ddlTemplates.ItemsLoading

        If ddlTemplates.Items.Count > 0 Then Exit Sub

        Dim nItem As RibbonDropDownItem

        Dim fileEntries As String()
        Dim fileName As String

        If Directory.Exists(CStr(Environ("USERPROFILE")) & "\Documents\MyTemplates") Then
            fileEntries = Directory.GetFiles(CStr(Environ("USERPROFILE")) & "\Documents\MyTemplates")
        Else
            Exit Sub
        End If

        nItem = Globals.Factory.GetRibbonFactory().CreateRibbonDropDownItem()
        nItem.Label = ""
        ddlTemplates.Items.Add(nItem)
        nItem = Nothing


        For Each fileName In fileEntries
            If Right(fileName, 4) = ".htm" And InStr(fileName, "MySignature") = 0 Then
                nItem = Globals.Factory.GetRibbonFactory().CreateRibbonDropDownItem()
                nItem.Label = CStr(Path.GetFileNameWithoutExtension(fileName))
                ddlTemplates.Items.Add(nItem)
                nItem = Nothing
            End If
        Next

    End Sub



    Private Sub ddlTemplates_SelectionChanged(sender As Object, e As RibbonControlEventArgs) Handles ddlTemplates.SelectionChanged

        If ddlTemplates.SelectedItem.Label = "" Then Exit Sub
        Call ReplaceBodyText(ddlTemplates.SelectedItem.Label)
        ddlTemplates.SelectedItemIndex = 0

    End Sub
End Class
