﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MyEmailsForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.dgwMyMails = New System.Windows.Forms.DataGridView()
        Me.cmnSubject = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.cmnFrom = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.cmnReceived = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.cmnLModified = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.btnOpen = New System.Windows.Forms.Button()
        Me.btnClose = New System.Windows.Forms.Button()
        CType(Me.dgwMyMails, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'dgwMyMails
        '
        Me.dgwMyMails.AllowUserToAddRows = False
        Me.dgwMyMails.AllowUserToDeleteRows = False
        Me.dgwMyMails.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.dgwMyMails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgwMyMails.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.cmnSubject, Me.cmnFrom, Me.cmnReceived, Me.cmnLModified})
        Me.dgwMyMails.Location = New System.Drawing.Point(19, 12)
        Me.dgwMyMails.Name = "dgwMyMails"
        Me.dgwMyMails.ReadOnly = True
        Me.dgwMyMails.Size = New System.Drawing.Size(785, 248)
        Me.dgwMyMails.TabIndex = 0
        '
        'cmnSubject
        '
        Me.cmnSubject.HeaderText = "Subject"
        Me.cmnSubject.Name = "cmnSubject"
        Me.cmnSubject.ReadOnly = True
        Me.cmnSubject.Width = 300
        '
        'cmnFrom
        '
        Me.cmnFrom.HeaderText = "From"
        Me.cmnFrom.Name = "cmnFrom"
        Me.cmnFrom.ReadOnly = True
        Me.cmnFrom.Width = 200
        '
        'cmnReceived
        '
        Me.cmnReceived.HeaderText = "Received"
        Me.cmnReceived.Name = "cmnReceived"
        Me.cmnReceived.ReadOnly = True
        Me.cmnReceived.Width = 120
        '
        'cmnLModified
        '
        Me.cmnLModified.HeaderText = "Last Modified"
        Me.cmnLModified.Name = "cmnLModified"
        Me.cmnLModified.ReadOnly = True
        Me.cmnLModified.Width = 120
        '
        'btnOpen
        '
        Me.btnOpen.Location = New System.Drawing.Point(82, 270)
        Me.btnOpen.Name = "btnOpen"
        Me.btnOpen.Size = New System.Drawing.Size(104, 48)
        Me.btnOpen.TabIndex = 1
        Me.btnOpen.Text = "Open selected email"
        Me.btnOpen.UseVisualStyleBackColor = True
        '
        'btnClose
        '
        Me.btnClose.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnClose.Location = New System.Drawing.Point(665, 270)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(104, 48)
        Me.btnClose.TabIndex = 2
        Me.btnClose.Text = "Close the form"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'MyEmailsForm
        '
        Me.AcceptButton = Me.btnOpen
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.btnClose
        Me.ClientSize = New System.Drawing.Size(823, 326)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.btnOpen)
        Me.Controls.Add(Me.dgwMyMails)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "MyEmailsForm"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "My Emails"
        CType(Me.dgwMyMails, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents dgwMyMails As System.Windows.Forms.DataGridView
    Friend WithEvents cmnSubject As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents cmnFrom As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents cmnReceived As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents cmnLModified As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents btnOpen As System.Windows.Forms.Button
    Friend WithEvents btnClose As System.Windows.Forms.Button
End Class
